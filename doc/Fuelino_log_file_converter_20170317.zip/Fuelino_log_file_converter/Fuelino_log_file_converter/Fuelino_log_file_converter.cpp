#include "stdafx.h"

using namespace System;
using namespace System::Runtime::InteropServices;

// CALCULATES THE UBX CHECKSUM OF A CHAR ARRAY (2 bytes)
unsigned short COMM_calculate_checksum(unsigned char* array, unsigned char array_start, unsigned char array_length) {
	unsigned char CK_A = 0;
	unsigned char CK_B = 0;
	unsigned char i;
	for (i = 0; i < array_length; i++) {
		CK_A = CK_A + array[array_start + i];
		CK_B = CK_B + CK_A;
	}
	return ((CK_A << 8) | (CK_B));
}

// Cleans dynamic data lists. This is necessary after finishing processing the data lists. To avoid RAM saturation.
void clean_data_lists(){
	// Clean Data Blocks
	data_block_class* data_blocks_clr_tmp = data_blocks_index; // Starting point
	while (data_blocks_clr_tmp != nullptr){ // until there is an element found
		data_block_class* data_blocks_now_clear = data_blocks_clr_tmp;
		data_blocks_clr_tmp = data_blocks_clr_tmp->next;
		delete data_blocks_now_clear; // remove element
	}
	data_blocks_index = nullptr; // Initialize the index pointer

	// Clean IMU Blocks
	IMUMgm_class* IMUMgm_blocks_clr_tmp = IMUMgm_blocks_index; // Starting point
	while (IMUMgm_blocks_clr_tmp != nullptr) { // until there is an element found
		IMUMgm_class* IMUMgm_blocks_now_clear = IMUMgm_blocks_clr_tmp;
		IMUMgm_blocks_clr_tmp = IMUMgm_blocks_clr_tmp->next;
		delete IMUMgm_blocks_now_clear; // remove element
	}
	IMUMgm_blocks_index = nullptr; // Initialize the index pointer

	// Clean LAM Blocks
	LambdaMgm_class* LambdaMgm_blocks_clr_tmp = LambdaMgm_blocks_index; // Starting point
	while (LambdaMgm_blocks_clr_tmp != nullptr) { // until there is an element found
		LambdaMgm_class* LambdaMgm_blocks_now_clear = LambdaMgm_blocks_clr_tmp;
		LambdaMgm_blocks_clr_tmp = LambdaMgm_blocks_clr_tmp->next;
		delete LambdaMgm_blocks_now_clear; // remove element
	}
	LambdaMgm_blocks_index = nullptr; // Initialize the index pointer

	GPS_clear_GPS_data_blocks(); // Clears GPS filtered data blocks
}

int main(array<System::String ^> ^args)
{
	printf("Fuelino Log Data Conversion Tool v1.0beta3\n");
	printf("Compatible with Fuelino Proto3\n\n");
	printf("Searching for Fuelino log files (FLNxxxxx.LOG)...\n"); // FLNxxxxx.LOG
	// Input File name scanning (0 - MAX_FILE_NUM)
	FILE *infile = NULL; // input raw data file (BINARY)
	FILE *outfile_interpolation; // output CSV file (ASCII)
	FILE *outfile_ecu_gps; // output CSV file (ASCII)
	FILE *outfile_lambda; // output CSV file (ASCII)
	FILE *outfile_imu; // output CSV file (ASCII)
	String ^ input_file_name;
	String ^ output_file_name_interpolation;
	String ^ output_file_name_ecu_gps;
	String ^ output_file_name_lambda;
	String ^ output_file_name_imu;
	for (unsigned int file_number_raw_data = 0; file_number_raw_data < MAX_FILE_NUM; file_number_raw_data++){
		// Try to find the file with this name
		bool file_input_valid = false;
		input_file_name = "Files/FLN"; // starting value (input)
		String ^ output_file_name = "Files/FLN"; // starting value (output), basic string
		if (file_number_raw_data < 10) input_file_name += "0";
		if (file_number_raw_data < 100) input_file_name += "0";
		if (file_number_raw_data < 1000) input_file_name += "0";
		if (file_number_raw_data < 10000) input_file_name += "0";
		input_file_name += Convert::ToString(file_number_raw_data);
		input_file_name += ".LOG";
		IntPtr ptrToNativeString = Marshal::StringToHGlobalAnsi(input_file_name);
		char* nativeString = static_cast<char*>(ptrToNativeString.ToPointer());
		fopen_s(&infile, nativeString, "rb");
		if (infile != NULL) { // Input raw file was found
			// Creates output file
			if (file_number_raw_data < 10) output_file_name += "0";
			if (file_number_raw_data < 100) output_file_name += "0";
			if (file_number_raw_data < 1000) output_file_name += "0";
			if (file_number_raw_data < 10000) output_file_name += "0";
			output_file_name += Convert::ToString(file_number_raw_data);
			output_file_name_interpolation = output_file_name + "_int.csv";
			output_file_name_ecu_gps = output_file_name + "_ecu_gps.csv";
			output_file_name_lambda = output_file_name + "_lam.csv";
			output_file_name_imu = output_file_name + "_imu.csv";
			ptrToNativeString = Marshal::StringToHGlobalAnsi(output_file_name_interpolation);
			nativeString = static_cast<char*>(ptrToNativeString.ToPointer());
			fopen_s(&outfile_interpolation, nativeString, "w");
			ptrToNativeString = Marshal::StringToHGlobalAnsi(output_file_name_ecu_gps);
			nativeString = static_cast<char*>(ptrToNativeString.ToPointer());
			fopen_s(&outfile_ecu_gps, nativeString, "w");
			ptrToNativeString = Marshal::StringToHGlobalAnsi(output_file_name_lambda);
			nativeString = static_cast<char*>(ptrToNativeString.ToPointer());
			fopen_s(&outfile_lambda, nativeString, "w");
			ptrToNativeString = Marshal::StringToHGlobalAnsi(output_file_name_imu);
			nativeString = static_cast<char*>(ptrToNativeString.ToPointer());
			fopen_s(&outfile_imu, nativeString, "w");
			file_input_valid = true;
		}

		// Input file was found, and also output file was created
		if (file_input_valid == true){
			_sleep(500);
			printf("\nFile found (%s).\n", input_file_name);
			unsigned char temp_char;
			unsigned int char_counter = 0;
			unsigned long ECU_packets_counter = 0; // read packets
			unsigned long ECU_packets_counter_errors = 0;
			unsigned long GPS_packets_counter = 0; // read packets
			unsigned long GPS_packets_counter_errors = 0;
			unsigned long IMU_packets_counter = 0; // read packets
			unsigned long IMU_packets_counter_errors = 0;
			unsigned long LAM_packets_counter = 0; // read packets
			unsigned long LAM_packets_counter_errors = 0;
			unsigned char buffer_temp[64];
			bool read_started_ECUd = false;
			bool read_started_UBX = false;
			bool read_started_IMU = false;
			bool read_started_LAM = false;
			data_block_class* data_blocks_now = nullptr; // Initialize pointer to NULL
			IMUMgm_class* IMUMgm_block_now = nullptr; // Initialize pointer to NULL
			LambdaMgm_class* LambdaMgm_block_now = nullptr; // Initialize pointer to NULL
			while (!feof(infile)){
				temp_char = fgetc(infile);
				bool reset_condition_request = false;
				if (!read_started_ECUd && !read_started_UBX && !read_started_IMU && !read_started_LAM){
					if (temp_char == 'd') read_started_ECUd = true;
					if (temp_char == 0xB5) read_started_UBX = true;
					if (temp_char == 0x49) read_started_IMU = true; // Imu, 'I'
					if (temp_char == 0x4C) read_started_LAM = true; // Lambda ('L' = 0x4C)
					char_counter = 0;
				}
				if (read_started_ECUd || read_started_UBX || read_started_IMU || read_started_LAM){
					buffer_temp[char_counter] = temp_char;
					char_counter++;
					if (read_started_ECUd && (char_counter == ECU_PACKET_LENGTH)){
						unsigned short CK_SUM = COMM_calculate_checksum(buffer_temp, 0, (char_counter - 2));
						unsigned char Ck_A = CK_SUM >> 8; // CK_A
						unsigned char Ck_B = CK_SUM & 0xFF; // CK_B
						if ((buffer_temp[(char_counter - 2)] == Ck_A) && (buffer_temp[(char_counter - 1)] == Ck_B)){ // Checkum check OK
							data_block_class* data_block_tmp = new data_block_class; // Create new block
							data_block_tmp->ECU_validity = true; // set validity for ECU message
							data_block_tmp->EngineMgm.parse_ECU_packet(buffer_temp); // Extrapolates raw data from input packet
							if (data_blocks_now != nullptr){ // Write Old Values in the module
								data_block_tmp->EngineMgm.time_stamp_temp_old = data_blocks_now->EngineMgm.time_stamp_temp;
								data_block_tmp->EngineMgm.engine_speed_calc_old = data_blocks_now->EngineMgm.engine_speed_calc; // save old value
								data_block_tmp->EngineMgm.injection_counter_buffer_old = data_blocks_now->EngineMgm.injection_counter_buffer_raw; // save old value
								data_block_tmp->EngineMgm.time_last_injection = data_blocks_now->EngineMgm.time_last_injection; // save old value
								data_block_tmp->EngineMgm.cutoff_mode = data_blocks_now->EngineMgm.cutoff_mode; // save cutoff status
							}
							data_block_tmp->EngineMgm.elaborate_raw_data(); // Elaborates raw data
							if (data_blocks_index == nullptr) data_blocks_index = data_block_tmp;
							data_block_tmp->previous = data_blocks_now;
							if (data_block_tmp->previous != nullptr) data_block_tmp->previous->next = data_block_tmp;
							data_blocks_now = data_block_tmp; // update the present block for next step
						}
						else{ // Checksum NG
							if (VERBOSE_CHECKSUM_ERRORS) printf("ECU checksum error. Size: %d. CkA(c)=%d. CkB(c)=%d. CkA(r)=%d. CkB(r)=%d.\n", char_counter, Ck_A, Ck_B, buffer_temp[(char_counter - 2)], buffer_temp[(char_counter - 1)]);
							ECU_packets_counter_errors++;
						}
						ECU_packets_counter++;
						reset_condition_request = true; // reset conditions
					}
					if (read_started_UBX){
						if ((char_counter == 2) && (temp_char != 0x62)) reset_condition_request = true; // strange UBX NAV
						if ((char_counter == 3) && (temp_char != 0x01)) reset_condition_request = true; // strange UBX NAV
						if ((char_counter == 4) && (temp_char != UBX_NAV_POSLLH_BYTE) && (temp_char != UBX_NAV_TIMEGPS_BYTE) && (temp_char != UBX_NAV_TIMEUTC_BYTE)) reset_condition_request = true; // strange UBX NAV
						if (((char_counter == UBX_NAV_POSLLH_CHARS) && (buffer_temp[3] == UBX_NAV_POSLLH_BYTE)) || // NAV_POSLLH received completely
							((char_counter == UBX_NAV_TIMEGPS_CHARS) && (buffer_temp[3] == UBX_NAV_TIMEGPS_BYTE)) ||  // NAV_TIMEGPS received completely
							((char_counter == UBX_NAV_TIMEUTC_CHARS) && (buffer_temp[3] == UBX_NAV_TIMEUTC_BYTE))){ // NAV_TIMEUTC received completely
							unsigned short CK_SUM = COMM_calculate_checksum(buffer_temp, 2, (char_counter - 4));
							unsigned char Ck_A = CK_SUM >> 8; // CK_A
							unsigned char Ck_B = CK_SUM & 0xFF; // CK_B
							if ((buffer_temp[(char_counter - 2)] == Ck_A) && (buffer_temp[(char_counter - 1)] == Ck_B)){ // Checkum check OK
								if ((data_blocks_now != nullptr) && (data_blocks_now->GPS_validity == false)){
									data_blocks_now->GPS_validity = true;
									data_blocks_now->GPSMgm.time_stamp = data_blocks_now->EngineMgm.time_stamp_temp; // Time stamp Arduino
									data_blocks_now->GPSMgm.parse_GPS_message(buffer_temp, char_counter); // Extrapolates raw data from input packet
								}
							}
							else{
								if (VERBOSE_CHECKSUM_ERRORS) printf("[%d] GPS checksum error. Size: %d. CkA(c)=%d. CkB(c)=%d. CkA(r)=%d. CkB(r)=%d.\n", GPS_packets_counter, char_counter, Ck_A, Ck_B, buffer_temp[(char_counter - 2)], buffer_temp[(char_counter - 1)]);
								GPS_packets_counter_errors++;
							}
							GPS_packets_counter++;
							reset_condition_request = true;
						}
					}
					if (read_started_IMU && (char_counter == MPU6050_BUFFER_SD_WRITE_SIZE)){
						unsigned short CK_SUM = COMM_calculate_checksum(buffer_temp, 0, (char_counter - 2));
						unsigned char Ck_A = CK_SUM >> 8; // CK_A
						unsigned char Ck_B = CK_SUM & 0xFF; // CK_B
						if ((buffer_temp[(char_counter - 2)] == Ck_A) && (buffer_temp[(char_counter - 1)] == Ck_B)){ // Checkum check OK
							IMUMgm_class* IMUMgm_block_temp = new IMUMgm_class; // Create new block
							if (IMUMgm_block_now != nullptr) { // in case there is an old (not first element)
								IMUMgm_block_temp->time_ms_old = IMUMgm_block_now->time_ms; // old time
								IMUMgm_block_now->next = IMUMgm_block_temp; // Next of previous
								IMUMgm_block_temp->previous = IMUMgm_block_now; // Previous of this
							}
							else { // first element of the list
								IMUMgm_blocks_index = IMUMgm_block_temp;
							}
							IMUMgm_block_temp->parse_IMU_message(buffer_temp); // Extrapolates raw data from input packet
							IMUMgm_block_now = IMUMgm_block_temp; // update index
						}
						else{
							if (VERBOSE_CHECKSUM_ERRORS) printf("IMU checksum error. Size: %d. CkA(c)=%d. CkB(c)=%d. CkA(r)=%d. CkB(r)=%d.\n", char_counter, Ck_A, Ck_B, buffer_temp[(char_counter - 2)], buffer_temp[(char_counter - 1)]);
							IMU_packets_counter_errors++;
						}
						IMU_packets_counter++;
						reset_condition_request = true;
					}
					if (read_started_LAM && (char_counter == ADCMGR_LAMBDA_ACQ_BUF_TOT)) {
						unsigned short CK_SUM = COMM_calculate_checksum(buffer_temp, 0, (char_counter - 2));
						unsigned char Ck_A = CK_SUM >> 8; // CK_A
						unsigned char Ck_B = CK_SUM & 0xFF; // CK_B
						if ((buffer_temp[(char_counter - 2)] == Ck_A) && (buffer_temp[(char_counter - 1)] == Ck_B)) { // Checkum check OK
							LambdaMgm_class* LambdaMgm_block_temp = new LambdaMgm_class; // Create new block
							if (LambdaMgm_block_now != nullptr) { // in case there is an old (not first element)
								LambdaMgm_block_now->next = LambdaMgm_block_temp; // Next of previous
								LambdaMgm_block_temp->previous = LambdaMgm_block_now; // Previous of this
							}
							else { // first element of the list
								LambdaMgm_blocks_index = LambdaMgm_block_temp;
							}
							LambdaMgm_block_temp->parse_Lambda_message(buffer_temp); // Retrieves data from the received packet
							LambdaMgm_block_now = LambdaMgm_block_temp; // update index
						}
						else {
							if (VERBOSE_CHECKSUM_ERRORS) printf("LAM checksum error. Size: %d. CkA(c)=%d. CkB(c)=%d. CkA(r)=%d. CkB(r)=%d.\n", char_counter, Ck_A, Ck_B, buffer_temp[(char_counter - 2)], buffer_temp[(char_counter - 1)]);
							LAM_packets_counter_errors++;
						}
						LAM_packets_counter++;
						reset_condition_request = true;
					}
					if (reset_condition_request == true){ // reset
						char_counter = 0;
						read_started_ECUd = false;
						read_started_UBX = false;
						read_started_IMU = false;
						read_started_LAM = false;
					}
				}
			}

			// Data processing (processes the acquired data-blocks before exporting to file)
			GPS_calculate_speed_orientation_reliable_blocks();

			// Data export
			export_ECU_GPS_data_file(outfile_ecu_gps); // Exports general data list
			export_interpolation_data_file(outfile_interpolation); // Exports interpolated data
			export_IMU_data_file(outfile_imu); // Exports IMU data list
			export_LAM_data_file(outfile_lambda); // Exports Lambda data list
			clean_data_lists(); // Cleans the dynamic lists
			fclose(infile); // close input file
			fclose(outfile_interpolation); // closes output file
			fclose(outfile_ecu_gps); // closes output file
			fclose(outfile_lambda); // closes output file
			fclose(outfile_imu); // closes output file
			printf("ECU packets read: %d. Errors: %d.\n", ECU_packets_counter, ECU_packets_counter_errors); // results
			printf("GPS packets read: %d. Errors: %d.\n", GPS_packets_counter, GPS_packets_counter_errors); // results
			printf("IMU packets read: %d. Errors: %d.\n", IMU_packets_counter, IMU_packets_counter_errors); // results
			printf("LAM packets read: %d. Errors: %d.\n", LAM_packets_counter, LAM_packets_counter_errors); // results
		}
	}

	// Keyboard key check
	printf("Finished. Press 'q' to exit.\n");
	bool quit_request = false;
	while (quit_request == false){
		if (_kbhit() != 0){
			char tasto = _getch();
			if (tasto == 'q') quit_request = true;
		}
	}
    return 0;
}