#ifndef IMUMgm_h
#define IMUMgm_h

#include <math.h> // Mathematics
#include "IMU_Fuelino.h" // IMU library for Fuelino

#define MPU6050_BUFFER_IMU_SIZE 12 // IMU data buffer size
#define MPU6050_BUFFER_SD_WRITE_SIZE (1 + 4 + MPU6050_BUFFER_IMU_SIZE + 2 + 2) // Size of buffer for SD write (header + time + data + temperature + checksum) | 21 bytes
#define MPU6050_SAMPLING_TIME_MS 50

// Calibration Data
#define AX_MIN (short)-15990
#define AX_MAX (short)16800
#define AY_MIN (short)-16300
#define AY_MAX (short)16300
#define AZ_MIN (short)-17500
#define AZ_MAX (short)15900
#define GX_OFF (short)-100
#define GY_OFF (short)250
#define GZ_OFF (short)-20

#define AX_OFF ((double)AX_MAX + (double)AX_MIN)/(double)2.0 // X acc offset
#define AY_OFF ((double)AY_MAX + (double)AY_MIN)/(double)2.0 // Y acc offset
#define AZ_OFF ((double)AZ_MAX + (double)AZ_MIN)/(double)2.0 // Z acc offset


class IMUMgm_class{

public:

	IMUMgm_class();
	void parse_IMU_message(unsigned char* buffer_temp);
	
	unsigned int time_ms;
	unsigned int time_ms_old;
	unsigned int time_ms_delta;
	unsigned int time_ms_modulo;
	short ax;
	short ay;
	short az;
	double temperature;
	short gx;
	short gy;
	short gz;
	double time_s = 0.0;

	double ax_double; // unit: g
	double ay_double; // unit: g
	double az_double; // unit: g

	double gx_double; // unit: deg/s
	double gy_double; // unit: deg/s
	double gz_double; // unit: deg/s

	// Calculated by IMU_Fuelino
	double yaw_deg = 0.0;
	double pitch_deg = 0.0;
	double roll_deg = 0.0;

	IMUMgm_class* previous = nullptr;
	IMUMgm_class* next = nullptr;
};

extern void export_IMU_data_file(FILE *outfile);
extern IMUMgm_class* IMUMgm_blocks_index;

#endif