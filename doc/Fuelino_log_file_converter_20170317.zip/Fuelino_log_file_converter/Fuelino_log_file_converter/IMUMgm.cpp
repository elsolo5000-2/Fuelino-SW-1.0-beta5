#include "stdafx.h"
#include "IMU_Fuelino_cal.h" // Calibrateable values

IMUMgm_class* IMUMgm_blocks_index = nullptr;

void export_IMU_data_file(FILE *outfile) {
	fprintf(outfile, "Time [ms],");
	fprintf(outfile, "Delta Time [ms],");
	fprintf(outfile, "Modulo [ms],");
	fprintf(outfile, "ax,");
	fprintf(outfile, "ay,");
	fprintf(outfile, "az,");
	fprintf(outfile, "gx,");
	fprintf(outfile, "gy,");
	fprintf(outfile, "gz,");
	fprintf(outfile, "yaw,");
	fprintf(outfile, "pitch,");
	fprintf(outfile, "roll,");
	fprintf(outfile, "Temperature,");
	fprintf(outfile, "\n");
	IMUMgm_class* IMU_block_tmp_now = IMUMgm_blocks_index; // Start from first element
	while (IMU_block_tmp_now != nullptr) {
		fprintf(outfile, "%d,", IMU_block_tmp_now->time_ms);
		fprintf(outfile, "%d,", IMU_block_tmp_now->time_ms_delta);
		fprintf(outfile, "%d,", IMU_block_tmp_now->time_ms_modulo);
		//fprintf(outfile, "%f,", (float)IMU_block_tmp_now->ax_double);
		//fprintf(outfile, "%f,", (float)IMU_block_tmp_now->ay_double);
		//fprintf(outfile, "%f,", (float)IMU_block_tmp_now->az_double);
		fprintf(outfile, "%d,", IMU_block_tmp_now->ax);
		fprintf(outfile, "%d,", IMU_block_tmp_now->ay);
		fprintf(outfile, "%d,", IMU_block_tmp_now->az);
		fprintf(outfile, "%d,", IMU_block_tmp_now->gx);
		fprintf(outfile, "%d,", IMU_block_tmp_now->gy);
		fprintf(outfile, "%d,", IMU_block_tmp_now->gz);
		fprintf(outfile, "%f,", (float)IMU_block_tmp_now->yaw_deg);
		fprintf(outfile, "%f,", (float)IMU_block_tmp_now->pitch_deg);
		fprintf(outfile, "%f,", (float)IMU_block_tmp_now->roll_deg);
		fprintf(outfile, "%f,", (float)IMU_block_tmp_now->temperature);
		fprintf(outfile, "\n");
		IMU_block_tmp_now = IMU_block_tmp_now->next;
	}
}

IMUMgm_class::IMUMgm_class(){
	time_ms_old = 0;
}

// Parses IMU message
void IMUMgm_class::parse_IMU_message(unsigned char* buffer_temp){

	time_ms = *((unsigned int*)&(buffer_temp[1])); // 1
	unsigned short ax_raw = ((unsigned short)(((unsigned short)buffer_temp[6] << 8) | ((unsigned short)buffer_temp[5]))); //
	unsigned short ay_raw = ((unsigned short)(((unsigned short)buffer_temp[8] << 8) | ((unsigned short)buffer_temp[7])));
	unsigned short az_raw = ((unsigned short)(((unsigned short)buffer_temp[10] << 8) | ((unsigned short)buffer_temp[9])));
	unsigned short gx_raw = ((unsigned short)(((unsigned short)buffer_temp[12] << 8) | ((unsigned short)buffer_temp[11])));
	unsigned short gy_raw = ((unsigned short)(((unsigned short)buffer_temp[14] << 8) | ((unsigned short)buffer_temp[13])));
	unsigned short gz_raw = ((unsigned short)(((unsigned short)buffer_temp[16] << 8) | ((unsigned short)buffer_temp[15]))); //
	unsigned short temp_raw = ((unsigned short)(((unsigned short)buffer_temp[18] << 8) | ((unsigned short)buffer_temp[17]))); // 
	ax = *((short*)(&ax_raw));
	ay = *((short*)(&ay_raw));
	az = *((short*)(&az_raw));
	short temp_short = *((short*)(&temp_raw));
	temperature = ((double)temp_short / (double)340.0) + (double)36.53; // Converts to Celsius
	gx = *((short*)(&gx_raw));
	gy = *((short*)(&gy_raw));
	gz = *((short*)(&gz_raw));

	ax_double = ((double)ax - (double)AX_OFF) * 2.0 / ((double)AX_MAX - (double)AX_MIN); // acceleration [g]
	ay_double = ((double)ay - (double)AY_OFF) * 2.0 / ((double)AY_MAX - (double)AY_MIN); // acceleration [g]
	az_double = ((double)az - (double)AZ_OFF) * 2.0 / ((double)AZ_MAX - (double)AZ_MIN); // acceleration [g]

	time_s = (double)time_ms / (double)1000.0;
	time_ms_delta = time_ms - time_ms_old; // Delta time between this sample and previous
	time_ms_modulo = time_ms % MPU6050_SAMPLING_TIME_MS; // Modulo

	// Manages IMU_Fuelino module
	IMU_Fuelino.ax = ax; // Acceleration raw
	IMU_Fuelino.ay = ay;
	IMU_Fuelino.az = az;
	IMU_Fuelino.gx = gx; // Gyroscope raw
	IMU_Fuelino.gy = gy;
	IMU_Fuelino.gz = gz;
	IMU_Fuelino.integration_time = (double)time_ms_delta / (double)1000.0;
	IMU_Fuelino.calculation_task(); // Calculation task
	yaw_deg = RAD_TO_DEG * IMU_Fuelino.yaw_out; // Outputs
	pitch_deg = RAD_TO_DEG * IMU_Fuelino.pitch_out;
	roll_deg = RAD_TO_DEG * IMU_Fuelino.roll_out;
}