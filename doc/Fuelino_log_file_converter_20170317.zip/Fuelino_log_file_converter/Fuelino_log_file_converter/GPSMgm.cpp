#include "stdafx.h"

#define RAD_TO_DEG (double)57.295777951 // convert radiants to degree
#define DEG_TO_RAD (double)1.0/RAD_TO_DEG // convert radiants to degree
#define M_PI (double)3.14159  // pi greco value
#define EARTH_RADIUS (double)6378137.0; // Earth radius [m]
//#define MAX_DELTA_DIST_GPS (double)100.0 // maximum position difference between one GPS sample and the next [m]

// Constants for filtering reliable data
#define GPS_HACC_MAX (double)35.0 // maximum accuracy (horizontal) [m] until GPS data is considered reliable
#define GPS_VACC_MAX (double)35.0 // maximum accuracy (vertical) [m] until GPS data is considered reliable
#define GPS_SPEED_DELTA_TIME_MAX (double)2.0 // max time between one sample and the previous, for speed calculation

GPS_data_block_class* GPS_data_blocks_index = nullptr; // Starting point of dynamic list
GPS_data_block_class* GPS_data_blocks_now = nullptr; // Temporary index for storing new blocks

// Calculates the speed [km/h] starting from time (s), latitude (deg) and longitude (deg), and height [m] of 2 points
double GPS_speed_on_geoid(double t1, double lat1, double lon1, double hei1, double t2, double lat2, double lon2, double hei2) {
	double dlong = (lon2 - lon1) * DEG_TO_RAD;
	double dlat = (lat2 - lat1) * DEG_TO_RAD;
	double a = pow(sin(dlat / 2.0), 2) + cos(lat1*DEG_TO_RAD) * cos(lat2*DEG_TO_RAD) * pow(sin(dlong / 2.0), 2);
	double c = 2 * atan2(sqrt(a), sqrt(1 - a));
	double distance = c * EARTH_RADIUS; // Distance [m]
	double delta_t = t2 - t1;
	if (delta_t != 0.0) {
		return 3.6*(distance / delta_t); // speed in km/h
	}
	else {
		return 0.0;
	}
}

GPSMgm_class::GPSMgm_class(){
	// nothing
}

void GPSMgm_class::parse_GPS_message(unsigned char* buffer_temp, unsigned int char_counter){

	if (char_counter == UBX_NAV_TIMEUTC_CHARS){
		iTOW = ((double)(*((unsigned int*)&(buffer_temp[6]))) / (double)1000.0); // U4
		tAcc = ((double)(*((unsigned int*)&(buffer_temp[10]))) / (double)1000000000.0); // U4
		nano = *((int*)&buffer_temp[14]);
		year = *((unsigned short*)&buffer_temp[18]);
		month = *((unsigned char*)&buffer_temp[20]);
		day = *((unsigned char*)&buffer_temp[21]);
		hour = *((unsigned char*)&buffer_temp[22]);
		min = *((unsigned char*)&buffer_temp[23]);
		sec = *((unsigned char*)&buffer_temp[24]);
		valid = *((unsigned char*)&buffer_temp[25]);
		message_type = 0; // TIME
	}
	else if (char_counter == UBX_NAV_POSLLH_CHARS){
		iTOW = ((double)(*((unsigned int*)&(buffer_temp[6]))) / (double)1000.0); // U4
		lon = ((double)(*((int*)&(buffer_temp[10]))) / (double)10000000.0); // I4
		lat = ((double)(*((int*)&(buffer_temp[14]))) / (double)10000000.0); // I4
		height = ((double)(*((int*)&(buffer_temp[18]))) / (double)1000.0); // I4
		hMSL = ((double)(*((int*)&(buffer_temp[22]))) / (double)1000.0); // I4
		hAcc = ((double)(*((unsigned int*)&(buffer_temp[26]))) / (double)1000.0); // U4
		vAcc = ((double)(*((unsigned int*)&(buffer_temp[30]))) / (double)1000.0); // U4
		message_type = 1; // POSITION
	}

	// Filters only reliable Position messages and puts them in a list
	if (message_type == 1) { // Position message
		if ((hAcc <= GPS_HACC_MAX) && (vAcc <= GPS_VACC_MAX)) { // Horizontal and vertical accuracy are into the reliability range
			GPS_data_block_class* GPS_data_block_temp = new GPS_data_block_class; // Create new block
			if (GPS_data_blocks_now != nullptr) { // in case there is an old (not first element)
				GPS_data_blocks_now->next = GPS_data_block_temp; // Next of previous
				GPS_data_block_temp->previous = GPS_data_blocks_now; // Previous of this
			}
			else { // first element of the list
				GPS_data_blocks_index = GPS_data_block_temp;
			}

			// Copy data
			GPS_data_block_temp->time_stamp = time_stamp; // Arduino time stamp
			GPS_data_block_temp->iTOW = iTOW; // time of week
			GPS_data_block_temp->lat = lat;
			GPS_data_block_temp->lon = lon;
			GPS_data_block_temp->height = height;
			GPS_data_block_temp->hMSL = hMSL;

			GPS_data_blocks_now = GPS_data_block_temp; // go to the next
		}
	}
}

// Clears GPS data blocks dynamic list from RAM memory
void GPS_clear_GPS_data_blocks() {
	GPS_data_block_class* GPS_data_blocks_clr_tmp = GPS_data_blocks_index; // Starting point
	while (GPS_data_blocks_clr_tmp != nullptr) { // until there is an element found
		GPS_data_block_class* GPS_data_blocks_now_clear = GPS_data_blocks_clr_tmp;
		GPS_data_blocks_clr_tmp = GPS_data_blocks_clr_tmp->next;
		delete GPS_data_blocks_now_clear; // remove element
	}
	GPS_data_blocks_index = nullptr; // Initialize the index pointer
	GPS_data_blocks_now = nullptr;
}

// Scans all acquired blocks and calculates the speed
void GPS_calculate_speed_orientation_reliable_blocks() {
	GPS_data_block_class* GPS_data_block_tmp_now = GPS_data_blocks_index; // Start from first element
	while (GPS_data_block_tmp_now != nullptr) {
		double speed_prev;
		double speed_next;
		bool speed_prev_validity = false;
		bool speed_next_validity = false;
		double delta_time_tmp;
		GPS_data_block_tmp_now->GPS_speed = 0.0; // tentative value
		if (GPS_data_block_tmp_now->previous != nullptr) { // previous is available
			delta_time_tmp = GPS_data_block_tmp_now->iTOW - GPS_data_block_tmp_now->previous->iTOW; // delta time
			if (abs(delta_time_tmp) <= GPS_SPEED_DELTA_TIME_MAX) {
				speed_prev = GPS_speed_on_geoid(GPS_data_block_tmp_now->previous->iTOW, GPS_data_block_tmp_now->previous->lat, GPS_data_block_tmp_now->previous->lon, GPS_data_block_tmp_now->previous->height, GPS_data_block_tmp_now->iTOW, GPS_data_block_tmp_now->lat, GPS_data_block_tmp_now->lon, GPS_data_block_tmp_now->height);
				speed_prev_validity = true; // reliable
			}
		}
		else if (GPS_data_block_tmp_now->next != nullptr) { // next is available
			delta_time_tmp = GPS_data_block_tmp_now->next->iTOW - GPS_data_block_tmp_now->iTOW; // delta time
			if (abs(delta_time_tmp) <= GPS_SPEED_DELTA_TIME_MAX) {
				speed_next = GPS_speed_on_geoid(GPS_data_block_tmp_now->iTOW, GPS_data_block_tmp_now->lat, GPS_data_block_tmp_now->lon, GPS_data_block_tmp_now->height, GPS_data_block_tmp_now->next->iTOW, GPS_data_block_tmp_now->next->lat, GPS_data_block_tmp_now->next->lon, GPS_data_block_tmp_now->next->height);
				speed_next_validity = true; // reliable
			}
		}
		else { // Not possible to calculate speed and orientation (no previous and no next)
			// do nothing
		}
		if ((speed_prev_validity == true) || (speed_next_validity == true)) { // at least one speed could be calculated
			GPS_data_block_tmp_now->GPS_speed_orientation_val = true; // speed was calculated properly at least from one side
			if ((speed_prev_validity == true) && (speed_next_validity == true)) { // both
				GPS_data_block_tmp_now->GPS_speed = (speed_prev + speed_next) / 2; // average
			}
			else if (speed_prev_validity == true) { // previous only
				GPS_data_block_tmp_now->GPS_speed = speed_prev; // previous
			}
			else { // next only
				GPS_data_block_tmp_now->GPS_speed = speed_next; // next
			}
		}
		GPS_data_block_tmp_now = GPS_data_block_tmp_now->next; // go to next element
	}
}