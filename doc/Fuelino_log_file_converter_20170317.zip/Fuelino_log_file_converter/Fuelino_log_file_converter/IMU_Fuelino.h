// IMU Library. Last update: 13 February 2017 
// Davide Cavaliere www.monocilindro.com dadez87-at-gmail.com

#ifndef IMU_Fuelino_h
#define IMU_Fuelino_h

#include <tchar.h>
#include <string>
#include <conio.h>
#include <time.h>
#include <math.h>

// History samples for calculating statistics (average and sigma) and real-time corrections
#define A_HIST_NUM (unsigned int)10 // number of samples for acceleration sensor history
#define G_HIST_NUM (unsigned int)10 // number of samples for gyroscope sensor history

// IMU Class
class IMU_Fuelino_class{

public:
	IMU_Fuelino_class(); // constructor, to initialize data
	void calculation_task(); // This function does the job. It should be called from outside.
	double integration_time = 0.0; // Integration time [s]
	short ax, ay, az; // Acceleration raw data [LSB]
	short gx, gy, gz; // Gyroscope raw data [LSB]
	bool yaw_zero_request = false; // Yaw angle zeroing request from visualization tool (sets Yaw angle to 0.0)
	bool yaw_filtering_req = false; // Filtering request coming from GPS module
	double q_int_out[4]; // Output Quaternion
	double yaw_out = 0.0; // Output [rad]
	double pitch_out = 0.0; // Output [rad]
	double roll_out = 0.0; // Output [rad]

private:
	void correct_raw_data(); // fixes the sign and scale, and arranges data into float format
	void calculate_rotation_matrix_elements(double yaw_in, double pitch_in, double roll_in, double M[3][3]);
	void calculate_quaternion_elements(double R_a[3][3], double* q_a);
	void calculate_pitchroll_from_acceleration();
	void calculate_yawpitchroll_from_quaternions(double* q_in, double* yaw_out, double* pitch_out, double* roll_out);
	void integrate_quaternion_g(double* q_in, double* q_out);
	void normalize_quaternion(double* q_in, double* q_out);
	void statistics_calculation();
	void fuse_yawpitchroll_block();
	void evaluate_yaw_rotation_turns(double yaw_input);
	void quaternion_product(double* q_in1, double* q_in2, double* q_out);
	void Madgwick_updateIMU(double* q_in, double ax, double ay, double az, double gx, double gy, double gz, double int_time, double madg_beta, double* q_out);

	bool first_execution_done = false; // Becomes 1 after first execution (when time old is known)
	double ax_f, ay_f, az_f; // Acceleration [g]
	double gx_f, gy_f, gz_f; // Gyroscope [rad/s]
	double a_f_modulo = 0.0; // Acceleration modulus [g]
	double pitch_a = 0.0; // pitch calculated from accelerometer data
	double roll_a = 0.0; // roll calculated from accelerometer data
	double yaw_old = 0.0; // used to estimate turns
	double yaw_fuse, pitch_fuse, roll_fuse; // yaw, pitch, roll calculated from fusion
	double M_rot[3][3]; // rotation matrix calculated from yaw, pitch, roll
	double q_int_in[4]; // quaternion (before integration)
	int turns_clockwise = 0; // how many turns clockwise have been done

	// Offsets estimation variables for gyroscope data
	double gx_f_offset = 0.0;
	double gy_f_offset = 0.0;
	double gz_f_offset = 0.0;

	// History variables
	double a_mod_samples_hist[A_HIST_NUM];
	double gx_samples_hist[G_HIST_NUM];
	double gy_samples_hist[G_HIST_NUM];
	double gz_samples_hist[G_HIST_NUM];
	unsigned int a_samples_index;
	unsigned int g_samples_index;

	// Filter variable
	double filter_req_pitchroll; // filter constant for yaw and pitch (depends on how acceleration data is reliable)
};

extern IMU_Fuelino_class IMU_Fuelino;

#endif