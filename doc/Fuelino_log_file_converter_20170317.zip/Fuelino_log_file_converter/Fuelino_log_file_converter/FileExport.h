#ifndef FileExport_h
#define FileExport_h

// Export options
#define VERBOSE_CHECKSUM_ERRORS 0 // checksum errors verbose
#define MAX_FILE_NUM 1024 // maximum number for file name searched on Hard Disk
#define EXPORT_INTERRUPT_TIME 1 // Exports INT1 and INT2 times
#define EXPORT_ECUd 1
#define EXPORT_GPS 1
#define EXPORT_IMU 1
#define EXPORT_GENERAL_DTIME (double)0.1 // Time difference when exporting [s]

// Read data structure
class data_block_class {

public:
	// Data
	EngineMgm_class EngineMgm;
	GPSMgm_class GPSMgm;

	// Validity
	bool ECU_validity = false;
	bool GPS_validity = false;
	bool IMU_validity = false;

	// Indexing
	data_block_class* previous = nullptr;
	data_block_class* next = nullptr;
};

extern data_block_class* data_blocks_index;
extern void export_ECU_GPS_data_file(FILE *outfile);
extern void export_interpolation_data_file(FILE *outfile);

#endif