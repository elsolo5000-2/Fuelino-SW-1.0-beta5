#include "stdafx.h"

#define MAX_GPS_SPEED_TIME_DIFFERENCE (double)3.0

data_block_class* data_blocks_index = nullptr;

// Linear Interpolation function
double interpolazione(double x1, double y1, double x2, double y2, double x) {
	double dy = y2 - y1; // delta x
	double dx = x2 - x1; // delta y
	return (y1 + (dy / dx)*(x - x1));
}

// Exports Interpolated General data to CSV Excel file
void export_interpolation_data_file(FILE *outfile) {
	// Header
	fprintf(outfile, "Time [s],");
	fprintf(outfile, "Engine Speed [rpm],");
	fprintf(outfile, "Throttle [%%],");
	fprintf(outfile, "Inj Time [us],");
	fprintf(outfile, "Inj Ext Time [us],");
	fprintf(outfile, "Cutoff,");
	fprintf(outfile, "yaw[deg],");
	fprintf(outfile, "pitch[deg],");
	fprintf(outfile, "roll[deg],");
	fprintf(outfile, "Speed[km/h],");
	fprintf(outfile, "Injection Count,");
	fprintf(outfile, "Lambda [V],");
	fprintf(outfile, "latitude,");
	fprintf(outfile, "longitude,");
	fprintf(outfile, "height[m],");
	fprintf(outfile, "temp[degC],");
	fprintf(outfile, "\n");
	double time_export_now = 0.0; // Start from time 0 s
	data_block_class* data_block_tmp_now = data_blocks_index; // Start from first element
	GPS_data_block_class* GPS_data_blocks_tmp = GPS_data_blocks_index; // Starting point
	IMUMgm_class* IMU_data_blocks_tmp = IMUMgm_blocks_index; // Starting point
	while (data_block_tmp_now != nullptr) {
		fprintf(outfile, "%f,", (float)time_export_now);

		// Finds ECU datablock(s) and interpolates their data
		bool interpolation_ECU_ok = false; // temporary value
		unsigned short injection_counter_int = 0; // temporary value
		unsigned int delta_inj_tick_int = 0; // temporary value
		double engine_speed_int = 0.0; // rpm // temporary value
		double throttle_int = 0.0; // % // temporary value
		double lambda_int = 0.0; // V // temporary value
		double extension_time_ticks_buffer = 0.0; // us // temporary value
		bool cutoff_mode = false; // temporary value
		if (data_block_tmp_now != nullptr) { // if a GPS block is available
			while (data_block_tmp_now != nullptr) { // Finds the next GPS element, if present
				if (data_block_tmp_now->EngineMgm.time_stamp_temp >= time_export_now) break;
				data_block_tmp_now = data_block_tmp_now->next; // go to the next
			}
			if ((data_block_tmp_now != nullptr) && (data_block_tmp_now->previous != nullptr)) { // can perform interpolation
				injection_counter_int = data_block_tmp_now->EngineMgm.injection_counter_buffer_raw;
				delta_inj_tick_int = data_block_tmp_now->EngineMgm.delta_inj_tick_buffer_raw;
				engine_speed_int = data_block_tmp_now->EngineMgm.engine_speed_calc;
				throttle_int = data_block_tmp_now->EngineMgm.throttle_buffer;
				lambda_int = data_block_tmp_now->EngineMgm.lambda_buffer;
				extension_time_ticks_buffer = data_block_tmp_now->EngineMgm.extension_time_ticks_buffer;
				cutoff_mode = data_block_tmp_now->EngineMgm.cutoff_mode;
				interpolation_ECU_ok = true; // interpolation was done correctly
			}
		}

		// Finds GPS datablock(s) and interpolates their data
		double speed_int = 0.0; // temporary value
		double lat_int = 0.0; // temporary value
		double lon_int = 0.0; // temporary value
		double height_int = 0.0; // temporary value
		bool interpolation_GPS_ok = false; // temporary value
		bool interpolation_SPD_ok = false; // temporary value
		if (GPS_data_blocks_tmp != nullptr) { // if a GPS block is available
			while (GPS_data_blocks_tmp != nullptr) { // Finds the next GPS element, if present
				if ((GPS_data_blocks_tmp->time_stamp >= time_export_now) && (GPS_data_blocks_tmp->GPS_speed_orientation_val == true)) break;
				GPS_data_blocks_tmp = GPS_data_blocks_tmp->next; // go to the next
			}
			// At the end of this cycle, the GPS time stamp should be higher than the ECU time stamp (with exception to the last, which is null)
			GPS_data_block_class* GPS_data_blocks_tmp2 = GPS_data_blocks_tmp;
			while (GPS_data_blocks_tmp2 != nullptr) { // Finds the previous GPS element, if present
				if ((GPS_data_blocks_tmp2->time_stamp <= time_export_now) && (GPS_data_blocks_tmp2->GPS_speed_orientation_val == true)) break;
				GPS_data_blocks_tmp2 = GPS_data_blocks_tmp2->previous; // go to the previous
			}
			// At the end of this cycle, the GPS time stamp should be lower than the ECU time stamp
			if ((GPS_data_blocks_tmp != nullptr) && (GPS_data_blocks_tmp2 != nullptr)) { // can perform interpolation (not first and not last)
				if ((abs(GPS_data_blocks_tmp->time_stamp - GPS_data_blocks_tmp2->time_stamp) <= MAX_GPS_SPEED_TIME_DIFFERENCE) && (GPS_data_blocks_tmp->GPS_speed_orientation_val == true) && (GPS_data_blocks_tmp2->GPS_speed_orientation_val == true)) { // reliability check
					speed_int = interpolazione(GPS_data_blocks_tmp2->time_stamp, GPS_data_blocks_tmp2->GPS_speed, GPS_data_blocks_tmp->time_stamp, GPS_data_blocks_tmp->GPS_speed, time_export_now);
					interpolation_SPD_ok = true; // interpolation was done correctly
				}
				lat_int = interpolazione(GPS_data_blocks_tmp2->time_stamp, GPS_data_blocks_tmp2->lat, GPS_data_blocks_tmp->time_stamp, GPS_data_blocks_tmp->lat, time_export_now);
				lon_int = interpolazione(GPS_data_blocks_tmp2->time_stamp, GPS_data_blocks_tmp2->lon, GPS_data_blocks_tmp->time_stamp, GPS_data_blocks_tmp->lon, time_export_now);
				height_int = interpolazione(GPS_data_blocks_tmp2->time_stamp, GPS_data_blocks_tmp2->height, GPS_data_blocks_tmp->time_stamp, GPS_data_blocks_tmp->height, time_export_now);
				interpolation_GPS_ok = true; // interpolation was done correctly
			}
		}

		// Finds IMU datablock(s) and interpolates their data
		double yaw_int = 0.0; // temporary value
		double pitch_int = 0.0; // temporary value
		double roll_int = 0.0; // temporary value
		double temp_int = 0.0; // temporary value
		bool interpolation_IMU_ok = false; // temporary value
		if (IMU_data_blocks_tmp != nullptr) { // if a GPS block is available
			while (IMU_data_blocks_tmp != nullptr) { // Finds the next GPS element, if present
				if (IMU_data_blocks_tmp->time_s >= time_export_now) break;
				IMU_data_blocks_tmp = IMU_data_blocks_tmp->next; // go to the next
			}
			// At the end of this cycle, the GPS time stamp should be higher than the ECU time stamp (with exception to the last, which is null)
			if ((IMU_data_blocks_tmp != nullptr) && (IMU_data_blocks_tmp->previous != nullptr)) { // can perform interpolation (not first and not last)
				temp_int = IMU_data_blocks_tmp->previous->temperature; // not changing so quickly
				yaw_int = interpolazione(IMU_data_blocks_tmp->previous->time_s, IMU_data_blocks_tmp->previous->yaw_deg, IMU_data_blocks_tmp->time_s, IMU_data_blocks_tmp->yaw_deg, time_export_now);
				pitch_int = interpolazione(IMU_data_blocks_tmp->previous->time_s, IMU_data_blocks_tmp->previous->pitch_deg, IMU_data_blocks_tmp->time_s, IMU_data_blocks_tmp->pitch_deg, time_export_now);
				roll_int = interpolazione(IMU_data_blocks_tmp->previous->time_s, IMU_data_blocks_tmp->previous->roll_deg, IMU_data_blocks_tmp->time_s, IMU_data_blocks_tmp->roll_deg, time_export_now);
				interpolation_IMU_ok = true; // interpolation was done correctly
			}
		}

		// MOST IMPORTANT DATA (10 signals)
		if (interpolation_ECU_ok == true) { // Interpolation found
			fprintf(outfile, "%f,", (float)engine_speed_int);
			fprintf(outfile, "%f,", (float)throttle_int);
			fprintf(outfile, "%d,", delta_inj_tick_int);
			fprintf(outfile, "%f,", (float)extension_time_ticks_buffer);
			fprintf(outfile, "%d,", cutoff_mode);
		}
		else { // Interpolation not found
			fprintf(outfile, ",,,,,");
		}
		if (interpolation_IMU_ok == true) { // Interpolation found
			fprintf(outfile, "%f,", (float)yaw_int);
			fprintf(outfile, "%f,", (float)pitch_int);
			fprintf(outfile, "%f,", (float)roll_int);
		}
		else { // Interpolation not found
			fprintf(outfile, ",,,");
		}
		if (interpolation_SPD_ok == true) { // Interpolation found
			fprintf(outfile, "%f,", (float)speed_int); // Might be 0.0, in case no speed can be calculated
		}
		else { // Interpolation not found
			fprintf(outfile, ",");
		}

		// LESS IMPORTANT DATA (positions from 11 and so on...)
		if (interpolation_ECU_ok == true) { // Interpolation found
			fprintf(outfile, "%d,", injection_counter_int);
			fprintf(outfile, "%f,", (float)lambda_int);
		}
		else { // Interpolation not found
			fprintf(outfile, ",,");
		}
		if (interpolation_GPS_ok == true) { // Interpolation found
			fprintf(outfile, "%f,", (float)lat_int);
			fprintf(outfile, "%f,", (float)lon_int);
			fprintf(outfile, "%f,", (float)height_int);
		}
		else { // Interpolation not found
			fprintf(outfile, ",,,");
		}
		if (interpolation_IMU_ok == true) { // Interpolation found
			fprintf(outfile, "%f,", (float)temp_int);
		}
		else { // Interpolation not found
			fprintf(outfile, ",");
		}

		fprintf(outfile, "\n");

		time_export_now += EXPORT_GENERAL_DTIME; // Increases logging time
	}
}

// Exports ECU and GPS data to CSV Excel file
void export_ECU_GPS_data_file(FILE *outfile) {
	// Header
	fprintf(outfile, "Packet No.,");
	fprintf(outfile, "Time [s],");
	fprintf(outfile, "Delta Time [s],");
	fprintf(outfile, "Injection Count,");
	fprintf(outfile, "2Rot Time [us],");
	fprintf(outfile, "Engine Speed [rpm],");
	fprintf(outfile, "Inj Time [us],");
	fprintf(outfile, "Throttle [%%],");
	fprintf(outfile, "Lambda [V],");
	fprintf(outfile, "Inj Ext Time [us],");
	if (EXPORT_INTERRUPT_TIME) fprintf(outfile, "Int 1 Time [us],");
	if (EXPORT_INTERRUPT_TIME) fprintf(outfile, "Int 2 Time [us],");
	fprintf(outfile, "DI Status,");
	fprintf(outfile, "Cutoff,");
	fprintf(outfile, "Speed[km/h],");
	fprintf(outfile, "iTOW[s],"); // GPS
	fprintf(outfile, "tAcc[s],");
	fprintf(outfile, "nano[ns],");
	fprintf(outfile, "Date,");
	fprintf(outfile, "Time,");
	fprintf(outfile, "valid,");
	fprintf(outfile, "latitude,");
	fprintf(outfile, "longitude,");
	fprintf(outfile, "height[m],");
	fprintf(outfile, "hMSL[m],");
	fprintf(outfile, "hAcc[m],");
	fprintf(outfile, "vAcc[m],");
	fprintf(outfile, "\n");
	// Export data
	data_block_class* data_block_tmp_now = data_blocks_index; // Start from first element
	GPS_data_block_class* GPS_data_blocks_tmp = GPS_data_blocks_index; // Starting point
	while (data_block_tmp_now != nullptr) {
		if ((data_block_tmp_now->ECU_validity == true)) { //&& (data_block_tmp_now->IMU_validity == true)){
			// Export ECU data
			if (EXPORT_ECUd) {
				fprintf(outfile, "%u,", data_block_tmp_now->EngineMgm.packet_cnt_raw);
				fprintf(outfile, "%f,", (float)data_block_tmp_now->EngineMgm.time_stamp_temp);
				fprintf(outfile, "%f,", (float)data_block_tmp_now->EngineMgm.delta_time_stamp_temp);
				fprintf(outfile, "%u,", data_block_tmp_now->EngineMgm.injection_counter_buffer_raw);
				fprintf(outfile, "%u,", data_block_tmp_now->EngineMgm.delta_time_tick_buffer_raw);
				fprintf(outfile, "%f,", (float)data_block_tmp_now->EngineMgm.engine_speed_calc);
				fprintf(outfile, "%u,", data_block_tmp_now->EngineMgm.delta_inj_tick_buffer_raw);
				fprintf(outfile, "%f,", (float)data_block_tmp_now->EngineMgm.throttle_buffer);
				fprintf(outfile, "%f,", (float)data_block_tmp_now->EngineMgm.lambda_buffer);
				fprintf(outfile, "%f,", (float)data_block_tmp_now->EngineMgm.extension_time_ticks_buffer);
				if (EXPORT_INTERRUPT_TIME) fprintf(outfile, "%u,", data_block_tmp_now->EngineMgm.INJ_exec_time_1_buffer_raw);
				if (EXPORT_INTERRUPT_TIME) fprintf(outfile, "%u,", data_block_tmp_now->EngineMgm.INJ_exec_time_2_buffer_raw);
				fprintf(outfile, "%u,", data_block_tmp_now->EngineMgm.digital_inputs_raw);
				fprintf(outfile, "%u,", data_block_tmp_now->EngineMgm.cutoff_mode);
				// Speed calculation at this time
				double GPS_speed_tmp = 0.0;
				if (GPS_data_blocks_tmp != nullptr) { // if a GPS block is available
					while (GPS_data_blocks_tmp != nullptr) { // Finds the next GPS element, if present
						if (GPS_data_blocks_tmp->time_stamp >= data_block_tmp_now->EngineMgm.time_stamp_temp) break;
						GPS_data_blocks_tmp = GPS_data_blocks_tmp->next; // go to the next
					}
					// At the end of this cycle, the GPS time stamp should be higher than the ECU time stamp (with exception to the last)
					if ((GPS_data_blocks_tmp != nullptr) && (GPS_data_blocks_tmp->previous != nullptr)) { // can perform interpolation (not first and not last)
						double t1 = GPS_data_blocks_tmp->previous->time_stamp; // lower time
						double t2 = GPS_data_blocks_tmp->time_stamp; // upper time
						double v1 = GPS_data_blocks_tmp->previous->GPS_speed; // lower speed
						double v2 = GPS_data_blocks_tmp->GPS_speed; // upper speed
						double dt = t2 - t1; // delta time
						double dv = v2 - v1; // delta speed
						double t_now = data_block_tmp_now->EngineMgm.time_stamp_temp; // time at this sample
						GPS_speed_tmp = v1 + (dv / dt)*(t_now - t1);
					}
				}
				fprintf(outfile, "%f,", (float)GPS_speed_tmp);
			}
			else {
				fprintf(outfile, ",,,,,,,,,,,,"); // 11 spaces
				if (EXPORT_INTERRUPT_TIME) fprintf(outfile, ",,"); // 2 spaces
			}
			// Export GPS data
			if (EXPORT_GPS && (data_block_tmp_now->GPS_validity == true)) {
				if (data_block_tmp_now->GPSMgm.message_type == 0) { // =0, TIME
					fprintf(outfile, "%f,", (float)data_block_tmp_now->GPSMgm.iTOW);
					fprintf(outfile, "%f,", (float)data_block_tmp_now->GPSMgm.tAcc);
					fprintf(outfile, "%d,", data_block_tmp_now->GPSMgm.nano);
					fprintf(outfile, "%u/", data_block_tmp_now->GPSMgm.year);
					fprintf(outfile, "%u/", data_block_tmp_now->GPSMgm.month);
					fprintf(outfile, "%u,", data_block_tmp_now->GPSMgm.day);
					fprintf(outfile, "%u:", data_block_tmp_now->GPSMgm.hour);
					fprintf(outfile, "%u:", data_block_tmp_now->GPSMgm.min);
					fprintf(outfile, "%u,", data_block_tmp_now->GPSMgm.sec);
					fprintf(outfile, "%u,", data_block_tmp_now->GPSMgm.valid);
					fprintf(outfile, ",,,,,,"); // 6 spaces
				}
				else { // = 1, POSITION
					fprintf(outfile, "%f,", (float)data_block_tmp_now->GPSMgm.iTOW);
					fprintf(outfile, ",,,,,"); // 5 spaces
					fprintf(outfile, "%f,", (float)data_block_tmp_now->GPSMgm.lat);
					fprintf(outfile, "%f,", (float)data_block_tmp_now->GPSMgm.lon);
					fprintf(outfile, "%f,", (float)data_block_tmp_now->GPSMgm.height);
					fprintf(outfile, "%f,", (float)data_block_tmp_now->GPSMgm.hMSL);
					fprintf(outfile, "%f,", (float)data_block_tmp_now->GPSMgm.hAcc);
					fprintf(outfile, "%f,", (float)data_block_tmp_now->GPSMgm.vAcc);
				}
			}
			else {
				fprintf(outfile, ",,,,,,,,,,,,"); // 12 spaces
			}
			fprintf(outfile, "\n");
		}
		data_block_tmp_now = data_block_tmp_now->next;
	}
}