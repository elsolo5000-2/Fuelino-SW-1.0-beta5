#ifndef LambdaMgm_h
#define LambdaMgm_h

#include <math.h> // Mathematics

#define ADCMGR_LAMBDA_ACQ_BUF_HEAD 9 // Header size (0x4C, Engine info 4x2 bytes)
#define ADCMGR_LAMBDA_ACQ_BUF_SIZE 32 // Total acquisitions of Lambda Sensor voltage (single byte, 0 - 255)
#define ADCMGR_LAMBDA_ACQ_BUF_TAIL 4 // Tail size (acquisition time + engine speed)
#define ADCMGR_LAMBDA_ACQ_BUF_TOT (ADCMGR_LAMBDA_ACQ_BUF_HEAD + ADCMGR_LAMBDA_ACQ_BUF_SIZE + ADCMGR_LAMBDA_ACQ_BUF_TAIL + 2) // Total size of packet: header, data, tail, checksum

class LambdaMgm_class{

public:
	LambdaMgm_class();
	void parse_Lambda_message(unsigned char* buffer_temp);

	unsigned short injection_counter_buffer_raw; // 1 
	unsigned int delta_time_tick_start_buffer; // 3
	unsigned int delta_inj_tick_buffer_start_raw; // 5
	unsigned short throttle_buffer_raw; // 7
	unsigned char lambda_buffer_raw[ADCMGR_LAMBDA_ACQ_BUF_SIZE]; // 32 bytes
	unsigned int time_req_acq; // time required for complete acquisition (us)
	unsigned int delta_inj_tick_buffer_end_raw; // 

	double throttle_volt = 0.0; // V
	double lambda_volt[ADCMGR_LAMBDA_ACQ_BUF_SIZE]; // V
	double engine_speed_calc_start = 0.0; // rpm

	LambdaMgm_class* previous = nullptr;
	LambdaMgm_class* next = nullptr;
};

extern void export_LAM_data_file(FILE *outfile); // Exports on file
extern LambdaMgm_class* LambdaMgm_blocks_index; // Starting pointer of the dynamic list

#endif