// IMU Library. Last update: 31 January 2017 
// Davide Cavaliere www.monocilindro.com dadez87-at-gmail.com

#include "stdafx.h"
#include "IMU_Fuelino.h" // Class and types definitions
#include "IMU_Fuelino_cal.h" // Calibrateable values

IMU_Fuelino_class IMU_Fuelino;

// Returns the sign of the input
double segno(double x) {
	return (x >= 0.0) ? +1.0 : -1.0;
}

// Madgwick filter modified algorithm. Uses double (64 bit) precision calculation. There should be no problem on fast computers.
void IMU_Fuelino_class::Madgwick_updateIMU(double* q_in, double ax, double ay, double az, double gx, double gy, double gz, double int_time, double madg_beta, double* q_out) {

	// Buffering (Input)
	double q0 = q_in[0];
	double q1 = q_in[1];
	double q2 = q_in[2];
	double q3 = q_in[3];

	// Calculation
	double Norm;
	double s0, s1, s2, s3;
	double qDot1, qDot2, qDot3, qDot4;
	double _2q0, _2q1, _2q2, _2q3, _4q0, _4q1, _4q2, _8q1, _8q2, q0q0, q1q1, q2q2, q3q3;
	// Rate of change of quaternion from gyroscope
	qDot1 = 0.5 * (-q1 * gx - q2 * gy - q3 * gz);
	qDot2 = 0.5 * (q0 * gx + q2 * gz - q3 * gy);
	qDot3 = 0.5 * (q0 * gy - q1 * gz + q3 * gx);
	qDot4 = 0.5 * (q0 * gz + q1 * gy - q2 * gx);
	// Compute feedback only if accelerometer measurement valid (avoids NaN in accelerometer normalisation)
	if (!((ax == 0.0) && (ay == 0.0) && (az == 0.0))) {
		// Auxiliary variables to avoid repeated arithmetic
		_2q0 = 2.0 * q0;
		_2q1 = 2.0 * q1;
		_2q2 = 2.0 * q2;
		_2q3 = 2.0 * q3;
		_4q0 = 4.0 * q0;
		_4q1 = 4.0 * q1;
		_4q2 = 4.0 * q2;
		_8q1 = 8.0 * q1;
		_8q2 = 8.0 * q2;
		q0q0 = q0 * q0;
		q1q1 = q1 * q1;
		q2q2 = q2 * q2;
		q3q3 = q3 * q3;
		// Gradient decent algorithm corrective step
		s0 = _4q0 * q2q2 + _2q2 * ax + _4q0 * q1q1 - _2q1 * ay;
		s1 = _4q1 * q3q3 - _2q3 * ax + 4.0f * q0q0 * q1 - _2q0 * ay - _4q1 + _8q1 * q1q1 + _8q1 * q2q2 + _4q1 * az;
		s2 = 4.0 * q0q0 * q2 + _2q0 * ax + _4q2 * q3q3 - _2q3 * ay - _4q2 + _8q2 * q1q1 + _8q2 * q2q2 + _4q2 * az;
		s3 = 4.0 * q1q1 * q3 - _2q1 * ax + 4.0 * q2q2 * q3 - _2q2 * ay;
		Norm = sqrt(s0 * s0 + s1 * s1 + s2 * s2 + s3 * s3); // normalise step magnitude
		s0 /= Norm;
		s1 /= Norm;
		s2 /= Norm;
		s3 /= Norm;
		// Apply feedback step
		qDot1 -= madg_beta * s0;
		qDot2 -= madg_beta * s1;
		qDot3 -= madg_beta * s2;
		qDot4 -= madg_beta * s3;
	}
	// Integrate rate of change of quaternion to yield quaternion
	q0 += qDot1 * int_time;
	q1 += qDot2 * int_time;
	q2 += qDot3 * int_time;
	q3 += qDot4 * int_time;
	// Normalise quaternion
	Norm = sqrt(q0 * q0 + q1 * q1 + q2 * q2 + q3 * q3);
	q0 /= Norm;
	q1 /= Norm;
	q2 /= Norm;
	q3 /= Norm;

	// Posting (Output)
	q_out[0] = q0;
	q_out[1] = q1;
	q_out[2] = q2;
	q_out[3] = q3;
}

// Calculates the quaternion product: q_out = q_in1 * q_in2
void IMU_Fuelino_class::quaternion_product(double* q_in1_tmp, double* q_in2, double* q_out) {
	double q_in1[4]; // buffer for input
	q_in1[0] = q_in1_tmp[0];
	q_in1[1] = q_in1_tmp[1];
	q_in1[2] = q_in1_tmp[2];
	q_in1[3] = q_in1_tmp[3];
	q_out[0] = q_in1[0] * q_in2[0] - q_in1[1] * q_in2[1] - q_in1[2] * q_in2[2] - q_in1[3] * q_in2[3];
	q_out[1] = q_in1[0] * q_in2[1] + q_in1[1] * q_in2[0] + q_in1[2] * q_in2[3] - q_in1[3] * q_in2[2];
	q_out[2] = q_in1[0] * q_in2[2] - q_in1[1] * q_in2[3] + q_in1[2] * q_in2[0] + q_in1[3] * q_in2[1];
	q_out[3] = q_in1[0] * q_in2[3] + q_in1[1] * q_in2[2] - q_in1[2] * q_in2[1] + q_in1[3] * q_in2[0];
	normalize_quaternion(q_out, q_out);
}

// Calculates average and sigma of acceleration and gyroscope raw data
void IMU_Fuelino_class::statistics_calculation() {

	// Saves current acceleration modulus and gyroscope samples in the history arrays
	a_mod_samples_hist[a_samples_index] = a_f_modulo;
	a_samples_index++; // increase array number
	if (a_samples_index >= A_HIST_NUM) a_samples_index = 0;
	gx_samples_hist[g_samples_index] = (double)gx; // raw value
	gy_samples_hist[g_samples_index] = (double)gy; // raw value
	gz_samples_hist[g_samples_index] = (double)gz; // raw value
	g_samples_index++; // increase array number
	if (g_samples_index >= G_HIST_NUM) g_samples_index = 0;

	// Calculates acceleration array average and sigma
	double average_acc_hist = 0.0; // average
	double sigma_acc_hist = 0.0; // sigma
	for (unsigned int i = 0; i < A_HIST_NUM; i++) {
		average_acc_hist += a_mod_samples_hist[i];
	}
	average_acc_hist = average_acc_hist / A_HIST_NUM; // average calculated
	for (unsigned int i = 0; i < A_HIST_NUM; i++) {
		sigma_acc_hist += pow((a_mod_samples_hist[i] - average_acc_hist), 2);
	}
	sigma_acc_hist = sigma_acc_hist / A_HIST_NUM;
	sigma_acc_hist = sqrt(sigma_acc_hist); // sigma calculated

	// Calculates gyroscope arrays average and sigma
	double average_gx_hist = 0.0;
	double average_gy_hist = 0.0;
	double average_gz_hist = 0.0;
	double sigma_gx_hist = 0.0;
	double sigma_gy_hist = 0.0;
	double sigma_gz_hist = 0.0;
	for (unsigned int i = 0; i < G_HIST_NUM; i++) {
		average_gx_hist += gx_samples_hist[i];
		average_gy_hist += gy_samples_hist[i];
		average_gz_hist += gz_samples_hist[i];
	}
	average_gx_hist /= G_HIST_NUM;
	average_gy_hist /= G_HIST_NUM;
	average_gz_hist /= G_HIST_NUM;
	for (unsigned int i = 0; i < G_HIST_NUM; i++) {
		sigma_gx_hist += pow(gx_samples_hist[i] - average_gx_hist, 2);
		sigma_gy_hist += pow(gy_samples_hist[i] - average_gy_hist, 2);
		sigma_gz_hist += pow(gz_samples_hist[i] - average_gz_hist, 2);
	}
	sigma_gx_hist = sigma_gx_hist / G_HIST_NUM; // average calculated
	sigma_gy_hist = sigma_gy_hist / G_HIST_NUM;
	sigma_gz_hist = sigma_gz_hist / G_HIST_NUM;
	sigma_gx_hist = sqrt(sigma_gx_hist); // sigma calculated
	sigma_gy_hist = sqrt(sigma_gy_hist);
	sigma_gz_hist = sqrt(sigma_gz_hist);

	// Determines the filtering contant, based on the the reliability of acceleration data
	filter_req_pitchroll = FILTER_PITCHROLL_MIN; // use minimum fusion coefficient, as tentative value
	if (average_acc_hist != 0.0) { // checks to avoid division by zero
		double sigma_acc_relative = sigma_acc_hist / average_acc_hist; // acceleration modulus: relative value of sigma, compared to the average
		if (abs(sigma_acc_relative) <= A_STEADY_STATE_SIGMA_THR) { // inside correct range
			double filter_req_pitchroll_now = FILTER_PITCHROLL_MAX; // use maximum fusion coefficient, but then filter it (next step)
			filter_req_pitchroll = FILTER_PITCHROLL_FILT_CONST*filter_req_pitchroll_now + ((double)1.0 - FILTER_PITCHROLL_FILT_CONST)*filter_req_pitchroll; // filtering of filter constant
		}
	}

	// Evaluate if the sensor is moving or not
	//double sigma_gx_relative, sigma_gy_relative, sigma_gz_relative;
	if ((average_gx_hist != 0.0) && (average_gy_hist != 0.0) && (average_gz_hist != 0.0)) { // checks to avoid division by zero
		//double sigma_gx_relative = sigma_gx_hist / average_gx_hist; // sigma relative to the modulus (x)
		//double sigma_gy_relative = sigma_gy_hist / average_gy_hist; // sigma relative to the modulus (y)
		//double sigma_gz_relative = sigma_gz_hist / average_gz_hist; // sigma relative to the modulus (z)
		if ((abs(sigma_gz_hist) <= G_STEADY_STATE_SIGMA_THR) && (abs(sigma_gz_hist) <= G_STEADY_STATE_SIGMA_THR) && (abs(sigma_gz_hist) <= G_STEADY_STATE_SIGMA_THR)){
			gx_f_offset = GYRO_TO_RAD*average_gx_hist;
			gy_f_offset = GYRO_TO_RAD*average_gy_hist;
			gz_f_offset = GYRO_TO_RAD*average_gz_hist;
		}
	}

	if (VERBOSE_MODE) printf("Acceleration modulo. Average= %f. Sigma= %f. Now= %f. Filter= %f.\n", average_acc_hist, sigma_acc_hist, a_f_modulo, filter_req_pitchroll);
	if (VERBOSE_MODE) printf("gx_off=%f gy_off=%f gz_off=%f gx_s=%f gy_s=%f gz_s=%f\n", gx_f_offset, gy_f_offset, gz_f_offset, sigma_gx_hist, sigma_gy_hist, sigma_gz_hist);

}

// Normalizes (module=1) a quaternion
void IMU_Fuelino_class::normalize_quaternion(double* q_in, double* q_out) {
	double Norm = 1 / sqrt(q_in[0] * q_in[0] + q_in[1] * q_in[1] + q_in[2] * q_in[2] + q_in[3] * q_in[3]);
	q_out[0] = q_in[0] / Norm;
	q_out[1] = q_in[1] / Norm;
	q_out[2] = q_in[2] / Norm;
	q_out[3] = q_in[3] / Norm;
}

// Integrates the quaternion based on gyroscope angle rate signals
void IMU_Fuelino_class::integrate_quaternion_g(double* q_in, double* q_out) {
	double wx = gx_f; // speed around X axis
	double wy = gy_f; // speed around Y axis
	double wz = gz_f; // speed around Z axis
	double wm = sqrt(gx_f*gx_f + gy_f*gy_f + gz_f*gz_f); // modulus of speed vector [rad/s]
	double angolo = (wm * integration_time) / (double)2.0; // speed integrated in time gives rotation angle [rad]. Need to divide by 2 (quaternion)
	double w0 = cos(angolo); // real part of the quaternion
	double sin_angolo_meno = -sin(angolo); // sinus of rotation angle, negated
	wx *= sin_angolo_meno; // immaginary part (i)
	wy *= sin_angolo_meno; // immaginary part (j)
	wz *= sin_angolo_meno; // immaginary part (k)
	double k = sqrt(((double)1.0 - w0*w0) / (wx*wx + wy*wy + wz*wz)); // needed to normalize the quaternion Search k to have modulus = 1. q = w0 + k*wx + k*wy + k*wz
	double qOmega[4]; // The following quaternion is the present rotation
	qOmega[0] = w0;
	qOmega[1] = wx*k;
	qOmega[2] = wy*k;
	qOmega[3] = wz*k;
	quaternion_product(qOmega, q_in, q_out); // Rotates the "q_in" of "qOmega", and outputs "q_out"
}

// Calculates rotation matrix elements values, starting from Tait-Bryan angles (yaw, pitch, roll)
void IMU_Fuelino_class::calculate_rotation_matrix_elements(double yaw_in, double pitch_in, double roll_in, double R_a[3][3]) {

	double sin_psi_a = sin(yaw_in); // yaw (psi)
	double cos_psi_a = cos(yaw_in);
	double sin_teta_a = sin(pitch_in); // pitch (teta)
	double cos_teta_a = cos(pitch_in);
	double sin_phi_a = sin(roll_in); // roll (phi)
	double cos_phi_a = cos(roll_in);

	// Calculates third column elements (Z axis), which require just the knowledge of pitch and roll angles
	R_a[0][2] = -sin_teta_a;
	R_a[1][2] = sin_phi_a*cos_teta_a;
	R_a[2][2] = cos_phi_a*cos_teta_a;

	// Calculates first and second column elements, which require the knowledge of yaw angle (psi)
	R_a[0][0] = cos_teta_a*cos_psi_a;
	R_a[0][1] = cos_teta_a*sin_psi_a;
	R_a[1][0] = -cos_phi_a*sin_psi_a + sin_phi_a*sin_teta_a*cos_psi_a;
	R_a[1][1] = cos_phi_a*cos_psi_a + sin_phi_a*sin_teta_a*sin_psi_a;
	R_a[2][0] = sin_phi_a*sin_psi_a + cos_phi_a*sin_teta_a*cos_psi_a;
	R_a[2][1] = -sin_phi_a*cos_psi_a + cos_phi_a*sin_teta_a*sin_psi_a;
}

// Calculates quaternion elements from a rotation matrix (Standard and simple method), only if the division is possible (!=0.0)
void IMU_Fuelino_class::calculate_quaternion_elements(double R_a[3][3], double* q_a) {
	double temp_q_a = (double)0.5 * sqrt((double)1.0 + R_a[0][0] + R_a[1][1] + R_a[2][2]);
	if (temp_q_a != (double)0.0) { // this value is used for division
		q_a[0] = temp_q_a;
		q_a[1] = (R_a[2][1] - R_a[1][2]) / ((double)4.0 * q_a[0]);
		q_a[2] = (R_a[0][2] - R_a[2][0]) / ((double)4.0 * q_a[0]);
		q_a[3] = (R_a[1][0] - R_a[0][1]) / ((double)4.0 * q_a[0]);
		normalize_quaternion(q_a, q_a); // modulus becomes 1
	}
	//printf("%f %f %f %f\n\n", q_a[0], q_a[1], q_a[2], q_a[3]);
}

// Calculates Yaw Pitch Roll angles from quaternion
void IMU_Fuelino_class::calculate_yawpitchroll_from_quaternions(double* q_in, double* yaw_out, double* pitch_out, double* roll_out) {
	*yaw_out = atan2((2.0 * q_in[1] * q_in[2] - 2.0 * q_in[0] * q_in[3]), (2.0 * q_in[0] * q_in[0] + 2.0 * q_in[1] * q_in[1]) - 1.0);
	*pitch_out = (-1.0) * asin((2.0 * q_in[1] * q_in[3] + 2.0 * q_in[0] * q_in[2]));
	*roll_out = atan2((2.0 * q_in[2] * q_in[3] - 2.0 * q_in[0] * q_in[1]), (2.0 * q_in[0] * q_in[0] + 2.0 * q_in[3] * q_in[3]) - 1.0);
	if (VERBOSE_MODE) printf("Yawt=%f Pitch= %f Roll=%f\n", RAD_TO_DEG * (*yaw_out), RAD_TO_DEG * (*pitch_out), RAD_TO_DEG * (*roll_out));
}

// Correct signs, scales inputs, and transforms data into floating point format
void IMU_Fuelino_class::correct_raw_data() {

	// Correct acceleration and gyroscope offsets (measured during offline calibration)
	ax -= ACC_X_OFFSET;
	ay -= ACC_Y_OFFSET;
	az -= ACC_Z_OFFSET;
	gx -= GYR_X_OFFSET;
	gy -= GYR_Y_OFFSET;
	gz -= GYR_Z_OFFSET;

	// Correct signs (some axis have negative sign compared on standard convention)
	//ax = -ax;
	//gy = -gy;
	//gz = -gz;
	az = -az; // Fuelino Proto3 on CBR125R - MPU6050
	gx = -gx; // Fuelino Proto3 on CBR125R - MPU6050
	gy = -gy; // Fuelino Proto3 on CBR125R - MPU6050

	// Calculates modulus of acceleration vector and normalizes acceleration data inside [-1, +1] range
	a_f_modulo = sqrt((double)ax * (double)ax + (double)ay * (double)ay + (double)az * (double)az);
	ax_f = (double)ax / a_f_modulo;
	ay_f = (double)ay / a_f_modulo;
	az_f = (double)az / a_f_modulo;

	// Checks that numbers are into [-1, +1] range (maybe this check is not necessary)
	/*if (ax_f < -1.0) ax_f = -1.0;
	if (ax_f > 1.0) ax_f = 1.0;
	if (ay_f < -1.0) ay_f = -1.0;
	if (ay_f > 1.0) ay_f = 1.0;
	if (az_f < -1.0) az_f = -1.0;
	if (az_f > 1.0) az_f = 1.0;*/

	// Transforms gyroscope data from raw data into rad/s
	gx_f = GYRO_TO_RAD*(double)gx;
	gy_f = GYRO_TO_RAD*(double)gy;
	gz_f = GYRO_TO_RAD*(double)gz;

	// Correct gyroscope offset (based on estimated offset values)
	if (G_OFFSET_CORR_ACT_FLAG) {
		gx_f -= gx_f_offset; // Standard value is 0.0
		gy_f -= gy_f_offset; // Standard value is 0.0
		gz_f -= gz_f_offset; // Standard value is 0.0
	}
}

// Calculates pitch and roll angles from acceleration data
void IMU_Fuelino_class::calculate_pitchroll_from_acceleration() {
	double pitch_old = pitch_out; // store old value (output value)
	double roll_old = roll_out; // store old value (output value)
	double sin_phi = (double)0.0; // tentative value
	double cos_phi = (double)1.0; // tentative value, not needed practically
	double sin_teta = -ax_f;
	double cos_teta = sqrt((double)1.0 - sin_teta*sin_teta);
	if (cos_teta != (double)0.0) {
		sin_phi = ay_f / cos_teta;
		cos_phi = az_f / cos_teta; // not needed
	}
	pitch_a = asin(sin_teta);
	roll_a = asin(sin_phi); // simple

							// Slope saturations (rationality limits)
	if (pitch_a < (pitch_old - MAX_PITCH_VAR_ACC)) pitch_a = pitch_old - MAX_PITCH_VAR_ACC;
	if (pitch_a > (pitch_old + MAX_PITCH_VAR_ACC)) pitch_a = pitch_old + MAX_PITCH_VAR_ACC;
	if (roll_a < (roll_old - MAX_ROLL_VAR_ACC)) roll_a = roll_old - MAX_ROLL_VAR_ACC;
	if (roll_a > (roll_old + MAX_ROLL_VAR_ACC)) roll_a = roll_old + MAX_ROLL_VAR_ACC;

	// Minimum and maximum saturations (rationality limits)
	if (pitch_a < MIN_PITCH) pitch_a = MIN_PITCH;
	if (pitch_a > MAX_PITCH) pitch_a = MAX_PITCH;
	if (roll_a < MIN_ROLL) roll_a = MIN_ROLL;
	if (roll_a > MAX_ROLL) roll_a = MAX_ROLL;

	//printf("%f %f \n", (float)pitch_a, (float)roll_a);
}

// This block fuses yaw, pitch and roll angles, depending on the reliability of the source
void IMU_Fuelino_class::fuse_yawpitchroll_block() {
	// Yaw angle fusion (depends on reliability of GPS data)
	/*if (yaw_filtering_req == true) { // Filtering request from external GPS module
	calculate_GPS_speed_and_orientation();
	double delta_GPS_yaw = 0.0; // abs(GPS_data.yaw_GPS - GPS_data_old.yaw_GPS); // difference between present and previous angles
	if (delta_GPS_yaw > M_PI) { // this part of code is useful when GPS angle inverts from -180 to +180 and vice-versa
	delta_GPS_yaw = (double)2.0 * M_PI - delta_GPS_yaw;
	}
	if ((GPS_data.yaw_GPS_reliability == true) && (GPS_data.speed_GPS_reliability == true) && (delta_GPS_yaw < GPS_DELTA_HEADING_MAX)){
	// Corrects the angles to let them be "on the same side"
	if ((GPS_data.yaw_GPS - yaw_int) > M_PI){ // GPS angle is higher, and difference higher than 180 deg
	yaw_int += 2 * M_PI; // add 360 degrees to the minimum angle
	}
	else if ((yaw_int - GPS_data.yaw_GPS) > M_PI){ // integrated angle is higher, and difference higher than 180 deg
	GPS_data.yaw_GPS += 2 * M_PI; // add 360 degrees to the minimum angle
	}
	double angle_difference = abs(GPS_data.yaw_GPS - yaw_int); // difference between GPS angle and previously estimated angle (yaw_int)
	if (angle_difference > GPS_INT_YAW_DIFF_MAX){ // if the difference is too big, I have to trust GPS data completely
	yaw_fuse = GPS_data.yaw_GPS;
	}
	else{ // otherwise (angles are similar), I perform a fusion using filter constant
	yaw_fuse = GPS_YAW_FILTER_CONSTANT*GPS_data.yaw_GPS + (1.0 - GPS_YAW_FILTER_CONSTANT)*yaw_int;
	}
	if (yaw_fuse > M_PI) GPS_data.yaw_GPS -= 2 * M_PI; // remove 360 degrees, if the angle is higher than 180 degrees
	//printf("%d %f\n", counter_temp, abs(GPS_data.yaw_GPS - GPS_data_old.yaw_GPS));
	//counter_temp++;
	}
	else{
	yaw_fuse = yaw_int; // Filtering was requested, but GPS data is not reliable enough
	}
	GPS_data_old = GPS_data; // updates old GPS struct
	}
	else{ // NO request from external GPS software module*/
	yaw_fuse = yaw_out; // use gyroscope previously integrated data
						//}

						// Pitch and Roll angles fusion (depends on reliability of Acceleration sensors data)
	pitch_fuse = filter_req_pitchroll*pitch_a + ((double)1.0 - filter_req_pitchroll)*pitch_out; // IIR filter
	roll_fuse = filter_req_pitchroll*roll_a + ((double)1.0 - filter_req_pitchroll)*roll_out; // IIR filter
}

// Evaluates if a complete turn has been done in clockwise / anticlockwise direction, by checking the difference between 2 consecutive angles
void IMU_Fuelino_class::evaluate_yaw_rotation_turns(double yaw_input) {
	double angle_difference = abs(yaw_input - yaw_old);
	if (angle_difference > M_PI) { // difference higher than 180 deg
		if ((segno(yaw_input) == (double)-1.0) && (segno(yaw_old) == (double)1.0)) {
			turns_clockwise++; // rotation was in clockwise direction
		}
		else if ((segno(yaw_input) == (double)1.0) && (segno(yaw_old) == (double)-1.0)) {
			turns_clockwise--; // rotation was in anti-clockwise direction
		}
	}
	yaw_old = yaw_input; // stores the old value for next calculation
}

// Calculation task assumes that raw data (ax, ay, az, gx, gy, gz) has already been acquired
// This function is the main block. It performs all calculations, starting from data correction to yaw, pitch, roll calculation
void IMU_Fuelino_class::calculation_task() {

	if (first_execution_done == true) { // first execution not done
		
		correct_raw_data(); // corrects sign and scale of raw data, corrects offsets, and transforms into floating point format

		// CAVALIERE FILTER: in case Cavaliere filter is used (monocilindro.com)		
		statistics_calculation(); // updates filter and offsets values
		calculate_pitchroll_from_acceleration(); // calculates pitch and roll angles from acceleration data
		fuse_yawpitchroll_block(); // fuses sensor data depending on their reliability
		calculate_rotation_matrix_elements(yaw_fuse, pitch_fuse, roll_fuse, M_rot); // calculates rotation matrix elements
		calculate_quaternion_elements(M_rot, q_int_in); // calculates quaternion starting from rotation matrix
		integrate_quaternion_g(q_int_in, q_int_out); // calculates "gyroscope" quaternion by integrating the gyroscope data, based on input quaternion

		// MADGWICK FILTER: in case Madgwick filter is used
		// Madgwick original algoritm works using an inverted quaternion, therefore the components have to be inverted before using the algorithm
		//calculate_rotation_matrix_elements(yaw_int, pitch_int, roll_int, M_rot); // calculates rotation matrix elements
		//calculate_quaternion_elements(M_rot, q_int_in); // calculates quaternion starting from rotation matrix
		/*q_int_in[0] = q_int_out[0];
		q_int_in[1] = -q_int_out[1];
		q_int_in[2] = -q_int_out[2];
		q_int_in[3] = -q_int_out[3];
		Madgwick_updateIMU(q_int_in, ax_f, ay_f, az_f, gx_f, gy_f, gz_f, INTEGRATION_TIME, 0.05, q_int_out);
		q_int_out[1] = -q_int_out[1];
		q_int_out[2] = -q_int_out[2];
		q_int_out[3] = -q_int_out[3];*/

		calculate_yawpitchroll_from_quaternions(q_int_out, &yaw_out, &pitch_out, &roll_out);
		if (yaw_zero_request == true) { // request to reset the Yaw angle
			yaw_out = 0.0; // resets the Yaw angle
		}
		else {
			evaluate_yaw_rotation_turns(yaw_out); // calculate if a complete turn has been done (clockwise / anticlockwise)
		}
	}
	
	first_execution_done = true; // first execution done

}

// Initializes the object
IMU_Fuelino_class::IMU_Fuelino_class() {

	// Output quaternion starting values
	q_int_out[0] = 1.0;
	q_int_out[1] = 0.0;
	q_int_out[2] = 0.0;
	q_int_out[3] = 0.0;

	// Resets acceleration sensors history
	a_samples_index = 0;
	for (unsigned int i = 0; i < A_HIST_NUM; i++) {
		a_mod_samples_hist[i] = 0.0;
	}

	// Resets gyroscope sensors history
	g_samples_index = 0;
	for (unsigned int i = 0; i < G_HIST_NUM; i++) {
		gx_samples_hist[i] = 0.0;
		gy_samples_hist[i] = 0.0;
		gz_samples_hist[i] = 0.0;
	}

	// Starting values of offsets for Gyroscope raw signal correction
	gx_f_offset = 0.0;
	gy_f_offset = 0.0;
	gz_f_offset = 0.0;

	// Filtering and external variables
	filter_req_pitchroll = FILTER_PITCHROLL_MIN; // filter constant for yaw and pitch (depends on how acceleration data is reliable)
	yaw_zero_request = 0; // yaw angle zeroing request from visualization tool (sets Yaw angle to 0.0)
	yaw_filtering_req = false; // filtering request coming from GPS module
}