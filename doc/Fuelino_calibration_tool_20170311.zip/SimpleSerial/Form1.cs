using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;


namespace SimpleSerial
{
    public partial class Form1 : Form
    {

        // Converts a character number (0-9) into an unsigned int number
        private UInt16 COMM_convert_char_array_to_num(char[] input_array, UInt16 array_start, UInt16 array_len)
        {
            UInt16 output_value_sum = 0;
            for (UInt16 ii = 0; ii < array_len; ii++)
            {
                UInt16 cypher_tmp = (UInt16)(input_array[array_start + ii] - '0'); // transforms cypher into number
                if (cypher_tmp > 9) return 0; // not valid number
                for (UInt16 jj = 0; jj < (array_len - ii - 1); jj++)
                {
                    cypher_tmp *= 10; // 100
                }
                output_value_sum += cypher_tmp;
            }
            if (output_value_sum > 255) return 0; // not valid number
            return output_value_sum; // converts the result in one byte
        }

        // Defines
        UInt16 INJ_INCR_RPM_MAPS_SIZE = 8; // Engine Speed compensation map size
        UInt16 INJ_INCR_THR_MAPS_SIZE = 8; // Throttle compensation map size
        //UInt16 INJ_INCR_TIM_MAPS_SIZE = 8; // Injection Time compensation map size

        bool seriale_connessa = false; // Serial not connected yet
        UInt16[] incrementi_rpm = new UInt16[8]; // increments, based on rpm, used by SW
        UInt16[] incrementi_thr = new UInt16[16]; // increments depending on throttle
        //UInt16[] incrementi_tim = new UInt16[8]; // increments depending on injection time
        UInt16[] incrementi_rpm_brkpts = { 2600, 3112, 4136, 5160, 7208, 11304, 15400, 23592 }; // breakpoints, size should be INJ_INCR_RPM_MAPS_SIZE

        UInt16 messaggio_in_char_cnt = 0;
        char[] messaggio_in_buffer = new char[64];
        //bool ECU_e_coming_mode = false;
        bool ECU_c_coming_mode = false;
        bool ECU_d_coming_mode = false;

        bool ECU_Data_polling_active = false;

        // Add this variable 
        string RxString; // Received string

        public Form1()
        {
            InitializeComponent();
            update_breakpoint();
            Load_Config_Settings_File();
        }

        // Connects to Serial Port
        private void buttonStart_Click(object sender, EventArgs e)
        {

            if (seriale_connessa == false) // Not yet connected
            {
                serialPort1.PortName = "COM" + Convert.ToString(numericUpDown3.Value);
                serialPort1.BaudRate = 57600;
                try
                {
                    textBox1.Text = "";
                    serialPort1.Open();
                    if (serialPort1.IsOpen)
                    {
                        seriale_connessa = true;
                        buttonStart.Text = "Disconnect";
                        textBox1.ReadOnly = false;
                        textBox4.Text = "Connected successfully";
                    }
                }
                catch (Exception eccezione)
                {
                    textBox4.Text = "Not possible to connect";
                    //Console.WriteLine("{0} Exception caught.", prova);
                }
            }
            else // Already connected. Disconnect!
            {
                stop_polling_ECU_data();
                textBox1.Text = "";
                if (serialPort1.IsOpen)
                {
                    serialPort1.Close();
                }
                seriale_connessa = false;
                buttonStart.Text = "Connect";
                textBox1.ReadOnly = true;
                textBox4.Text = "Disconnected";
            }
        }

        // Disconnects the serial port
        private void buttonStop_Click(object sender, EventArgs e)
        {

        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (serialPort1.IsOpen) serialPort1.Close();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void DisplayText(object sender, EventArgs e)
        {
            textBox1.AppendText(RxString);
            update_breakpoint();
        }

        private void Parse_Calibration_Message()
        {
            UInt16 rw_num_temp = COMM_convert_char_array_to_num(messaggio_in_buffer, 1, 1);
            UInt16 map_num_temp = COMM_convert_char_array_to_num(messaggio_in_buffer, 2, 1);
            UInt16 index_num_temp = COMM_convert_char_array_to_num(messaggio_in_buffer, 3, 2);
            UInt16 value_num_temp = COMM_convert_char_array_to_num(messaggio_in_buffer, 5, 3);
            if (map_num_temp == 0) // RPM
            {
                if (index_num_temp < INJ_INCR_RPM_MAPS_SIZE) incrementi_rpm[index_num_temp] = value_num_temp;
            }
            else if (map_num_temp == 1) // THR
            {
                if (index_num_temp < INJ_INCR_THR_MAPS_SIZE) incrementi_thr[index_num_temp] = value_num_temp;
            }
            /*else if (map_num_temp == 2) // TIM
            {
                if (index_num_temp < INJ_INCR_TIM_MAPS_SIZE) incrementi_tim[index_num_temp] = value_num_temp;
            }*/
            update_breakpoint();
        }

        private void Parse_Data_Message()
        {
            textBox6.Text = Convert.ToString((UInt32)messaggio_in_buffer[2] + (UInt32)(messaggio_in_buffer[3] << 8) + (UInt32)(messaggio_in_buffer[4] << 16) + (UInt32)(messaggio_in_buffer[5] << 24)); // Time
            textBox7.Text = Convert.ToString((UInt16)messaggio_in_buffer[6] + (UInt16)(messaggio_in_buffer[7] << 8)); // Inj Counter
            UInt32 delta_time_us = 4*((UInt32)messaggio_in_buffer[8] + (UInt32)(messaggio_in_buffer[9] << 8));
            /*Double RPM = 0;
            if (delta_time_us != 0) RPM = (Double)120000000 / (Double)delta_time_us;
            String RPM_string = RPM.ToString();
            String RPM_string2 = RPM_string.ToString();
            if (RPM_string2.Length > 7) RPM_string2 = RPM_string.Remove(7);
            textBox15.Text = RPM_string2; // RPM*/
            textBox8.Text = Convert.ToString(delta_time_us); // Delta Inj
            if (delta_time_us != 0) textBox15.Text = ((UInt32)120000000 / ((UInt32)delta_time_us)).ToString();
            textBox9.Text = Convert.ToString(4*((UInt16)messaggio_in_buffer[10] + (UInt16)(messaggio_in_buffer[11] << 8))); // Inj Time
            textBox10.Text = Convert.ToString(((Double)messaggio_in_buffer[12] + (Double)(messaggio_in_buffer[13] << 8))*(Double)5/(Double)1023); // Throttle
            textBox11.Text = Convert.ToString(((Double)messaggio_in_buffer[14] + (Double)(messaggio_in_buffer[15] << 8)) * (Double)5 / (Double)1023); // Lambda
            textBox12.Text = Convert.ToString(((UInt32)messaggio_in_buffer[16] + (UInt32)(messaggio_in_buffer[17] << 8))/2); // Extension
            textBox13.Text = Convert.ToString(4 * (UInt16)(messaggio_in_buffer[18])); // INT ON
            textBox14.Text = Convert.ToString(4 * (UInt16)(messaggio_in_buffer[19])); // INT OFF
            textBox16.Text = Convert.ToString((UInt16)messaggio_in_buffer[20]); // Input Status
        }

        private void Messaggio_Manager()
        {
            UInt16 char_ricevuti = (UInt16)RxString.Length;
            char[] buffer_temporaneo = new char[64];
            buffer_temporaneo = RxString.ToCharArray();
            for (UInt16 ii = 0; ii < char_ricevuti; ii++)
            {
                if (buffer_temporaneo[ii] == 'c' && ECU_c_coming_mode == false && ECU_d_coming_mode == false)
                { // calibration packet received
                    ECU_c_coming_mode = true;
                    messaggio_in_buffer[0] = buffer_temporaneo[ii];
                    messaggio_in_char_cnt = 1;
                }
                else if (buffer_temporaneo[ii] == 'd' && ECU_c_coming_mode == false && ECU_d_coming_mode == false)
                { // data packet received
                    ECU_d_coming_mode = true;
                    messaggio_in_buffer[0] = buffer_temporaneo[ii];
                    messaggio_in_char_cnt = 1;
                }
                else if ((ECU_c_coming_mode == true) || (ECU_d_coming_mode == true))
                { // continue to read from previous activation
                    messaggio_in_buffer[messaggio_in_char_cnt] = buffer_temporaneo[ii];
                    messaggio_in_char_cnt++;
                    if ((ECU_c_coming_mode == true) && (messaggio_in_char_cnt >= 8))
                    { // complete calibration message has been received
                        Parse_Calibration_Message();
                        messaggio_in_char_cnt = 0;
                        ECU_c_coming_mode = false;
                        this.Invoke(new EventHandler(DisplayText));
                    }
                    else if ((ECU_d_coming_mode == true) && (messaggio_in_char_cnt >= 23))
                    { // complete data message has been received
                        Parse_Data_Message();
                        messaggio_in_char_cnt = 0;
                        ECU_d_coming_mode = false;
                    }
                }
                else
                { // set everything to zero
                    //ECU_e_coming_mode = false;
                    ECU_c_coming_mode = false;
                    ECU_d_coming_mode = false;
                    messaggio_in_char_cnt = 0;
                }
            }
        }

        // Receives data from serial
        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            RxString = serialPort1.ReadExisting();
            Messaggio_Manager();
        }

        private void SendCalibReadReq(UInt16 map_num, UInt16 map_index)
        {
            if (!seriale_connessa)
            {
                textBox4.Text = "Serial not connected";
                return;
            }
            string buffer_invio = "";
            buffer_invio += "c0"; // c = calib, 0 = read
            buffer_invio += map_num; // Map number
            if (map_index < 10) buffer_invio += "0"; // Index number
            buffer_invio += map_index; // Index number
            buffer_invio += "000"; // // Value number
            buffer_invio += '\n'; // Enter
            buffer_invio += '\r'; // Enter
            serialPort1.Write(buffer_invio);
            textBox4.Text = "Sent Message: " + buffer_invio;
        }


        // Calibration Read request
        private void button1_Click(object sender, EventArgs e)
        {
            SendCalibReadReq((UInt16)numericUpDown1.Value, (UInt16)numericUpDown2.Value);
        }

        // Calibration Write request
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                double incremento_float = Convert.ToDouble(textBox3.Text.ToString());
                UInt16 incremento_int = Convert.ToUInt16((incremento_float * 256) / 50);
                textBox5.Text = incremento_int.ToString();
            }
            catch
            {
                textBox4.Text = "Input value is not valid";
                return;
            }
            if (!seriale_connessa)
            {
                textBox4.Text = "Serial not connected";
                return;
            }
            string buffer_invio = "";
            buffer_invio += "c1"; // c = calib, 1 = write
            buffer_invio += numericUpDown1.Value; // Map number
            if (numericUpDown2.Value < 10) buffer_invio += "0"; // Index number
            buffer_invio += numericUpDown2.Value; // Index number
            UInt16 valore = Convert.ToUInt16(textBox5.Text.ToString());
            if (valore > 255)
            {
                textBox4.Text = "Value out of range";
                return;
            }
            if (valore < 10) buffer_invio += "0"; // Value number
            if (valore < 100) buffer_invio += "0"; // Value number
            buffer_invio += valore; // Value number
            buffer_invio += '\n'; // Enter
            buffer_invio += '\r'; // Enter
            serialPort1.Write(buffer_invio);
            textBox4.Text = "Sent Message: " + buffer_invio;
        }

        private void update_breakpoint()
        {
            if (numericUpDown1.Value == 0)
            { // RPM map
                numericUpDown2.Maximum = INJ_INCR_RPM_MAPS_SIZE - 1; // 7 values maximum
                textBox2.Text = ((UInt32)120000000 / ((UInt32)incrementi_rpm_brkpts[(int)numericUpDown2.Value] * (UInt32)4)).ToString();
                textBox5.Text = incrementi_rpm[(int)numericUpDown2.Value].ToString();
                textBox3.Text = (Convert.ToDouble(incrementi_rpm[(int)numericUpDown2.Value]) * 50 / 256).ToString();
                label3.Text = "Rpm";
            }
            else if (numericUpDown1.Value == 1)
            { // THR map
                numericUpDown2.Maximum = INJ_INCR_THR_MAPS_SIZE - 1; // 15 values maximum
                textBox2.Text = ((Double)5.0/ (Double)INJ_INCR_THR_MAPS_SIZE * (Double)numericUpDown2.Value).ToString();
                textBox5.Text = incrementi_thr[(int)numericUpDown2.Value].ToString();
                textBox3.Text = (Convert.ToDouble(incrementi_thr[(int)numericUpDown2.Value]) * 50 / 256).ToString();
                label3.Text = "Throttle [V]";
            }
            /*else if (numericUpDown1.Value == 2)
            { // TIM map
                numericUpDown2.Maximum = INJ_INCR_TIM_MAPS_SIZE - 1; // 7 values maximum
                textBox2.Text = "0";
                textBox5.Text = incrementi_tim[(int)numericUpDown2.Value].ToString();
                textBox3.Text = (Convert.ToDouble(incrementi_tim[(int)numericUpDown2.Value]) * 50 / 256).ToString();
                label3.Text = "Inj Time [us]";
            }*/
        }

        private void Load_Config_Settings_File()
        {
            try
            {
                using (StreamReader sr = new StreamReader("settings.cfg"))
                {
                    string line;
                    line = sr.ReadLine();
                    if (line.StartsWith("COM") && (line.Length <= 5))
                    {
                        string line2 = line.Substring(3, line.Length - 3);
                        numericUpDown3.Value = Convert.ToUInt16(line2);
                    }
                    else
                    {
                        textBox4.Text = "Could not read port number";
                    }
                }
            }
            catch (Exception e)
            {
                textBox4.Text = "Could not load settings";
            }
        }

        // Map value changed
        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            update_breakpoint();
        }

        // Index value changed
        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            update_breakpoint();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        // Read all values
        private void button3_Click(object sender, EventArgs e)
        {
            ReadAllCalibValues();
        }

        // Programs Timer1 in order to read all the calibration values
        private void ReadAllCalibValues()
        {
            if (!seriale_connessa)
            {
                textBox4.Text = "Serial not connected";
                return;
            }
            numericUpDown1.Value = 0; // map number
            numericUpDown2.Value = 0; // index number
            timer1.Stop();
            timer1.Interval = 100; // 100ms
            timer1.Enabled = true;
            timer1.Start();
        }

        // Timer1 is used to read all calibration values
        private void timer1_Tick(object sender, EventArgs e)
        {
            SendCalibReadReq((UInt16)numericUpDown1.Value, (UInt16)numericUpDown2.Value);
            UInt16 max_maps_index = 0;
            if (numericUpDown1.Value == 0) max_maps_index = INJ_INCR_RPM_MAPS_SIZE; // rpm (8)
            if (numericUpDown1.Value == 1) max_maps_index = INJ_INCR_THR_MAPS_SIZE; // thr (8)
            //if (numericUpDown1.Value == 2) max_maps_index = INJ_INCR_TIM_MAPS_SIZE; // tim (8)
            UInt16 map_index_next = (UInt16)(numericUpDown2.Value + 1);
            if (map_index_next >= (UInt16)max_maps_index)
            { // max reached for this map
                UInt16 map_num_next = (UInt16)(numericUpDown1.Value + 1);
                if (map_num_next == 2)
                {
                    timer1.Stop();
                    timer1.Enabled = false; // stops timer (finished)
                    numericUpDown1.Value = 0; // map number
                    numericUpDown2.Value = 0; // index number
                    return; // finished all maps
                }
                numericUpDown1.Value++; // go to next map, next time
                numericUpDown2.Value = 0; // restart from element zero
            }
            else
            { // max not reached yet
                numericUpDown2.Value++; // go to next index of the same map
            }
            timer1.Stop();
            timer1.Interval = 100; // 100 millisecond
            timer1.Enabled = true;
            timer1.Start();
        }

        // Writes calibrations from RAM into EEPROM
        private void button4_Click(object sender, EventArgs e)
        {
            if (!seriale_connessa)
            {
                textBox4.Text = "Serial not connected";
                return;
            }
            string buffer_invio = "";
            buffer_invio += "c2"; // c = calib, 2 = write RAM into EEPROM
            buffer_invio += "2"; // All maps
            buffer_invio += "00"; // Index
            buffer_invio += "001"; // // Write values from RAM to EEPROM
            buffer_invio += '\n'; // Enter
            buffer_invio += '\r'; // Enter
            serialPort1.Write(buffer_invio);
            textBox4.Text = "Sent Message: " + buffer_invio;
            ReadAllCalibValues(); // Update values
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (!seriale_connessa)
            {
                textBox4.Text = "Serial not connected";
                return;
            }
            string buffer_invio = "";
            buffer_invio += "c2"; // c = calib, 2 = write EEPROM
            buffer_invio += "2"; // All maps
            buffer_invio += "00"; // Index
            buffer_invio += "000"; // // Write standard values
            buffer_invio += '\n'; // Enter
            buffer_invio += '\r'; // Enter
            serialPort1.Write(buffer_invio);
            textBox4.Text = "Sent Message: " + buffer_invio;
            ReadAllCalibValues(); // Update values
        }
        
        // Stops polling ECU data
        private void stop_polling_ECU_data()
        {
            button6.Text = "Start Polling";
            ECU_Data_polling_active = false; // Disable
            timer2.Stop();
            timer2.Enabled = false;
        }

        // Polling of ECU Binary Data ("d100") Enable/Disable button
        private void button6_Click(object sender, EventArgs e)
        {
            if (ECU_Data_polling_active == false) // Starts polling
            {
                button6.Text = "Stop Polling";
                ECU_Data_polling_active = true; // Disable
                timer2.Stop();
                timer2.Interval = 500; // 500 millisecond period
                timer2.Enabled = true;
                timer2.Start();
            }
            else // Stops polling
            {
                stop_polling_ECU_data();
            }
        }

        // Timer to send "d100" requests (Data requests)
        private void timer2_Tick(object sender, EventArgs e)
        {
            timer2.Enabled = true;
            timer2.Start();
            if (!seriale_connessa)
            {
                textBox4.Text = "Serial not connected";
                return;
            }
            string buffer_invio = "d100"; // ECU Binary Data request
            buffer_invio += '\n'; // Enter
            buffer_invio += '\r'; // Enter
            serialPort1.Write(buffer_invio);
            textBox4.Text = "Sent Message: " + buffer_invio;
        }

    }
}