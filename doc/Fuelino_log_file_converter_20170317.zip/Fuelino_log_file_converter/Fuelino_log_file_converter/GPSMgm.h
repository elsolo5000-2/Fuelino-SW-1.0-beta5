#ifndef GPSMgm_h
#define GPSMgm_h

#define UBX_NAV_POSLLH_BYTE 0x02
#define UBX_NAV_TIMEGPS_BYTE 0x20
#define UBX_NAV_TIMEUTC_BYTE 0x21
#define UBX_NAV_POSLLH_CHARS 36
#define UBX_NAV_TIMEGPS_CHARS 24
#define UBX_NAV_TIMEUTC_CHARS 28

class GPSMgm_class{

public:

	GPSMgm_class();
	void parse_GPS_message(unsigned char* buffer_temp, unsigned int char_counter);

	double time_stamp = 0; // time stamp Arduino (s)
	double iTOW = 0.0; // U4
	double tAcc = 0.0; // U4
	int nano = 0;
	unsigned short year = 0;
	unsigned char month = 0;
	unsigned char day = 0;
	unsigned char hour = 0;
	unsigned char min= 0;
	unsigned char sec = 0;
	unsigned char valid = 0;
	double lon = 0.0; // I4
	double lat = 0.0; // I4
	double height = 0.0; // I4
	double hMSL = 0.0; // I4
	double hAcc = 0.0; // U4
	double vAcc = 0.0; // U4

	unsigned int message_type = 0; // 0=TIME, 1=POS
};

// GPS data
class GPS_data_block_class {
public:
	double time_stamp = 0.0; // time stamp (s)
	double iTOW = 0.0; // time (s)
	double lat = 0.0; // latitude (deg)
	double lon = 0.0; // latitude (deg)
	double height = 0.0; //
	double hMSL = 0.0; //

	bool GPS_speed_orientation_val = false;
	double GPS_speed = 0.0; // speed calculated [km/h]
	double GPS_orientation = 0.0; // orientation [rad]

	GPS_data_block_class* previous = nullptr;
	GPS_data_block_class* next = nullptr;

};

extern GPS_data_block_class* GPS_data_blocks_index;
extern void GPS_clear_GPS_data_blocks();
extern void GPS_calculate_speed_orientation_reliable_blocks();

#endif