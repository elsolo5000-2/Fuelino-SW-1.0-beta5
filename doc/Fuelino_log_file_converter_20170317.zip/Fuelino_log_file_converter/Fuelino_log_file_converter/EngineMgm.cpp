#include "stdafx.h"

// Data Processing and Filtering constant
#define RPM_MAX_DRPM_DT (double)3000.0 // max rpm variation in 1 second
#define THROTTLE_MIN (unsigned short)112
#define THROTTLE_MAX (unsigned short)900
#define CUTOFF_MAX_TIME (double)0.1 // in case there is no new injection after this time [s], it will be considered cutoff

EngineMgm_class::EngineMgm_class(){
	init_old_variables();
}


// Initialize old variables
void EngineMgm_class::init_old_variables(){
	time_stamp_temp_old = 0.0; // time stamp of previous sample
	injection_counter_buffer_old = 0; // injection number at previous sample
	time_last_injection = 0.0; // time of last injection
	engine_speed_calc_old = 0.0; // engine speed calculated at previous sample
	cutoff_mode = false; // this mode becomes active when brake is pressed (injection cut)
}


// Parses incoming ECU packet
void EngineMgm_class::parse_ECU_packet(unsigned char* buffer_temp){

	packet_cnt_raw = buffer_temp[1]; // no unit, 0 - 255
	time_stamp_temp_raw = *((unsigned long*)&(buffer_temp[2])); // ms
	injection_counter_buffer_raw = *((unsigned short*)&(buffer_temp[6])); // no unit
	delta_time_tick_buffer_raw = *((unsigned short*)&(buffer_temp[8])) * 4; // us
	delta_inj_tick_buffer_raw = *((unsigned short*)&(buffer_temp[10])) * 4; // us
	throttle_buffer_raw = *((unsigned short*)&(buffer_temp[12])); // 0-1023
	lambda_buffer_raw = *((unsigned short*)&(buffer_temp[14])); // 0-1023
	extension_time_ticks_buffer_raw = *((unsigned short*)&(buffer_temp[16])); // 0.5us
	INJ_exec_time_1_buffer_raw = *((unsigned char*)&(buffer_temp[18])) * 4; // us
	INJ_exec_time_2_buffer_raw = *((unsigned char*)&(buffer_temp[19])) * 4; // us
	digital_inputs_raw = buffer_temp[20]; // no unit. Bit0 = Battery. Bit1 = External DI.

}


// Elaborates raw data
void EngineMgm_class::elaborate_raw_data(){

	time_stamp_temp = (double)time_stamp_temp_raw / (double)1000.0; // s
	if (time_stamp_temp < time_stamp_temp_old) init_old_variables();

	lambda_buffer = (double)lambda_buffer_raw * 5.0 / 1023.0;

	// Throttle raw voltage transformed into percentage
	if (throttle_buffer_raw <= THROTTLE_MIN){
		throttle_buffer = 0.0;
	}
	else if (throttle_buffer_raw >= THROTTLE_MAX){
		throttle_buffer = 100.0;
	}
	else{
		throttle_buffer = (float)(((double)(throttle_buffer_raw - THROTTLE_MIN))*(double)100.0 / (double)(THROTTLE_MAX - THROTTLE_MIN));
	}

	delta_time_stamp_temp = time_stamp_temp - time_stamp_temp_old; // delta time stamp

	// Analyze RPM and CUTOFF
	engine_speed_calc = engine_speed_calc_old; // tentative value is old value
	if ((injection_counter_buffer_raw == injection_counter_buffer_old)){ // there is no new injection
		if ((time_stamp_temp - time_last_injection) >= CUTOFF_MAX_TIME) { // enough time has passed from last injection
			cutoff_mode = true; // brake was pressed and no new injection is performed
		}
		//delta_inj_tick_buffer_raw = 0; // No injection
		//extension_time_ticks_buffer_raw = 0; // No injection
		//INJ_exec_time_1_buffer_raw = 0; // No injection
		//INJ_exec_time_2_buffer_raw = 0; // No injection
		// Maintain last calculated speed
	}
	else{ // there is a new injection
		time_last_injection = time_stamp_temp; // update last injection time
		if (cutoff_mode == true){
			cutoff_mode = false; // deactivate cutoff mode, since a new injection has been received
			// Maintain last calculated speed
		}
		else if (delta_time_tick_buffer_raw != 0){ // to avoid division by zero
			engine_speed_calc = ((double)120000000.0 / (double)delta_time_tick_buffer_raw); // raw rpm calculation
			double boundary_limit = 0.0; // boundary limits first value
			if (delta_time_stamp_temp > 0.0) boundary_limit = (double)RPM_MAX_DRPM_DT * delta_time_stamp_temp; // to avoid division by 0
			if (engine_speed_calc >= (engine_speed_calc_old + boundary_limit)){
				engine_speed_calc = engine_speed_calc_old + boundary_limit;
			}
			else if (engine_speed_calc <= (engine_speed_calc_old - boundary_limit)){
				engine_speed_calc = engine_speed_calc_old - boundary_limit;
			}
		}
	}

	extension_time_ticks_buffer = (double)extension_time_ticks_buffer_raw / (double)2.0; // us

}