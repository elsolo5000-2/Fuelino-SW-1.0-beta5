#ifndef IMU_Fuelino_cal_h
#define IMU_Fuelino_cal_h

// Constant values which should not be touched. 
// Do not touch these defines, unless you know what you are doing.
#define RAD_TO_DEG (double)57.295777951 // convert radiants to degree
#define DEG_TO_RAD (double)1.0/RAD_TO_DEG // convert radiants to degree
#define M_PI (double)3.14159  // pi greco value
#define INTEGRATION_TIME (double)0.1 // integration time (each sample is received at this interval time)
#define GYRO_SENSITIVITY (double)250.0/(double)32768.0 // 250 deg/s is the full scale, which corresponds to 2^15 = 32768
#define GYRO_TO_RAD (double)DEG_TO_RAD*GYRO_SENSITIVITY // needed to tranform sensor raw data into rad per second (3.14/180)*(1/32.8). Gyro range is 32.8 LSB/(deg/s) (Arduino range = 1000)
#define VERBOSE_MODE 0 // Flag to allow prints messages on screen

// Sensors signal offset. These offset will be removed from sensors raw signals (accelerometer and gyroscope signals).
// You should adapt these values to your sensors.
// In case of MPU-6050, each signal (3x acceleration, 3x gyroscope) corresponds to a 16bit signed integer (signed short)
#define ACC_X_OFFSET (short)0
#define ACC_Y_OFFSET (short)0
#define ACC_Z_OFFSET (short)0
#define GYR_X_OFFSET (short)-142
#define GYR_Y_OFFSET (short)234
#define GYR_Z_OFFSET (short)-10

// History samples for calculating statistics (average and sigma) and real-time corrections
#define A_STEADY_STATE_SIGMA_THR (double)0.05 // Threshold for acceleration modulo value: division between sigma and average
#define FILTER_PITCHROLL_FILT_CONST (double)0.2 // constant for filtering priority filter value (acceleration or gyroscope data priority)
#define FILTER_PITCHROLL_MIN (double)0.05 // when gyroscope pitch/roll has high priority (default = 0.1)
#define FILTER_PITCHROLL_MAX (double)0.25 // when acceleration pitch/roll has high priority (default = 0.3)

// Offset compensation in realtime, for gyroscope signals
#define G_OFFSET_CORR_ACT_FLAG 0 // Enables Gyroscope raw data offset correction algorithm
#define G_STEADY_STATE_SIGMA_THR (double)50.0 // Threshold for gyroscope value: division between sigma and average

// Acceleration Pitch and Roll angles: saturations and filtering constants
#define MAX_PITCH_VAR_ACC (double)30.0*(DEG_TO_RAD) // maximum variation between one sample and the next (acceleration sensor filtering)
#define MAX_ROLL_VAR_ACC (double)30.0*(DEG_TO_RAD) // maximum variation between one sample and the next (acceleration sensor filtering)
#define MIN_PITCH (double)-75.0*(DEG_TO_RAD) // minimum value (acceleration sensor filtering)
#define MAX_PITCH (double)+75.0*(DEG_TO_RAD) // maximum value (acceleration sensor filtering)
#define MIN_ROLL (double)-75.0*(DEG_TO_RAD) // minimum value (acceleration sensor filtering)
#define MAX_ROLL (double)+75.0*(DEG_TO_RAD) // maximum value (acceleration sensor filtering)

// GPS related constants
//#define GPS_YAW_FILTER_CONSTANT (double)0.50 // this constant is used when GPS data is reliable (default: 0.5)
//#define GPS_INT_YAW_DIFF_MAX (double)45.0*(DEG_TO_RAD) // if the difference between "int yaw" and "GPS yaw" is higher than this angle [rad], GPS data only is considered 
//#define GPS_DELTA_HEADING_MAX (double)20.0*(DEG_TO_RAD) // maximum heading difference between two consecutive samples [rad]
//#define MIN_PHY_SPEED (double)15.0 // minimum physically possible speed [km/h], used to consider GPS speed data reliable or not
//#define MAX_PHY_SPEED (double)140.0 // maximum physically possible speed [km/h], used to consider GPS speed data reliable or not
//#define MAX_DELTA_TIME_GPS (unsigned long)2000 // maximum time difference between one GPS sample and the next [ms]
//#define MAX_DELTA_DIST_GPS (double)100.0 // maximum position difference between one GPS sample and the next [m]

#endif