#include "stdafx.h"

void export_LAM_data_file(FILE *outfile) {
	fprintf(outfile, "Injection Count,");
	fprintf(outfile, "Engine Speed Start [rpm],");
	fprintf(outfile, "Inj Time Start [us],");
	fprintf(outfile, "Inj Time End [us],");
	fprintf(outfile, "Throttle,");
	fprintf(outfile, "Acq Time [us],");
	fprintf(outfile, "\n");
	LambdaMgm_class* Lambda_block_tmp_now = LambdaMgm_blocks_index; // Start from first element
	while (Lambda_block_tmp_now != nullptr) {
		fprintf(outfile, "%d,", Lambda_block_tmp_now->injection_counter_buffer_raw);
		fprintf(outfile, "%f,", (float)Lambda_block_tmp_now->engine_speed_calc_start);
		fprintf(outfile, "%d,", Lambda_block_tmp_now->delta_inj_tick_buffer_start_raw);
		fprintf(outfile, "%d,", Lambda_block_tmp_now->delta_inj_tick_buffer_end_raw);
		fprintf(outfile, "%d,", Lambda_block_tmp_now->throttle_buffer_raw);
		fprintf(outfile, "%d,", Lambda_block_tmp_now->time_req_acq);
		for (unsigned int i = 0; i < ADCMGR_LAMBDA_ACQ_BUF_SIZE; i++) {
			fprintf(outfile, "%f,", (float)Lambda_block_tmp_now->lambda_volt[i]);
		}
		fprintf(outfile, "\n");
		Lambda_block_tmp_now = Lambda_block_tmp_now->next;
	}
}

LambdaMgm_class::LambdaMgm_class(){

}

// Parses Lambda message
void LambdaMgm_class::parse_Lambda_message(unsigned char* buffer_temp){

	injection_counter_buffer_raw = *((unsigned short*)&(buffer_temp[1])); // no unit
	delta_time_tick_start_buffer = *((unsigned short*)&(buffer_temp[3])) * 4; // us
	delta_inj_tick_buffer_start_raw = *((unsigned short*)&(buffer_temp[5])) * 4; // us
	throttle_buffer_raw = *((unsigned short*)&(buffer_temp[7])); // 0-1023
	time_req_acq = *((unsigned short*)&(buffer_temp[9 + ADCMGR_LAMBDA_ACQ_BUF_SIZE])) * 4; // us
	delta_inj_tick_buffer_end_raw = *((unsigned short*)&(buffer_temp[9 + ADCMGR_LAMBDA_ACQ_BUF_SIZE + 2])) * 4; // us
	
	// Buffer and Calculated values
	for (unsigned int i = 0; i < ADCMGR_LAMBDA_ACQ_BUF_SIZE; i++) { // scan all buffer samples
		lambda_buffer_raw[i] = buffer_temp[9 + i];
		lambda_volt[i] = (double)lambda_buffer_raw[i] * (double)5.0 / (double)1024.0; // lambda voltage calculation
	}
	throttle_volt = (double)throttle_buffer_raw * (double)5.0 / (double)1024.0; // throttle voltage calculation
	if (delta_time_tick_start_buffer) engine_speed_calc_start = (double)120000000.0 / (double)delta_time_tick_start_buffer; // rpm calculation

}

LambdaMgm_class* LambdaMgm_blocks_index = nullptr;